import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/dashboard" component={Home} />
      <Route path="/courses" component={Home} />
      <Route path="/assignments" component={Home} />
      <Route path="/assignments/:id" component={Home} />
      <Route path="/submissions" component={Home} />
      <Route path="/grades" component={Home} />
      <Route path="/calendar" component={Home} />
      <Route path="/announcements" component={Home} />
      <Route path="/settings" component={Home} />
      <Route path="/admin" component={Home} />
      <Route path="/faculty" component={Home} />
      <Route path="/student" component={Home} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster position="top-right" />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
