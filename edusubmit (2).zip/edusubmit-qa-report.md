# EduSubmit QA, Security, UI, and Deployment-Readiness Report

**Review scope:** authentication boundary, Student Portal, Faculty Portal, Administrator Portal, database persistence, submission workflow, notification delivery, private files, responsive UI, performance, and production startup.

**Review date:** 2026-09-25

## Executive summary

EduSubmit is deployment-ready for the current Manus WebDev environment after two QA fixes: the storage proxy now requires an authenticated user and verifies file ownership or authorized course access, and assignment deep links now resolve to the student assignment detail view. The application passes TypeScript validation, the complete real-database Vitest suite, a production bundle build, a compiled-server HTTP smoke test, and live unauthenticated API security checks.

## Functional verification

| Area | Evidence | Result |
|---|---|---|
| Manus login entrypoint | Live preview click redirected to the Manus app-auth portal with the current origin callback and nonce-bound state | Passed |
| OAuth state validation | Live callback with a fake code and malformed state returned HTTP 403 before token exchange | Passed |
| Session persistence and logout | `server/auth.session.test.ts` and `server/auth.logout.test.ts` | Passed |
| Student dashboard, assignment browsing, submissions, grades, feedback | `server/student.workflow.test.ts`, `server/advanced.features.test.ts` | Passed |
| Faculty assignment, submission, evaluation, and marks publication | `server/faculty.workflow.test.ts` | Passed |
| Administrator user, department, course, enrollment, assignment, and announcement workflow | `server/admin.workflow.test.ts` | Passed |
| Notifications and deadline reminders | `server/advanced.features.test.ts` plus faculty workflow notification assertions | Passed |
| Database persistence | Real TiDB/MySQL records are created, queried, evaluated, and cleaned up by integration tests | Passed |
| Production startup | Compiled `dist/index.js` returned HTTP 200 and served the built application | Passed |

### Authentication boundary

EduSubmit delegates account creation, provider login, and password recovery to Manus OAuth rather than storing application passwords. The application-side login entrypoint and callback protections were verified. A complete signup and password-reset journey cannot be honestly claimed as end-to-end tested in this sandbox because it requires a real provider account and provider-managed recovery flow; no local password-reset implementation exists by design.

## Security review

Server-side role procedures remain authoritative. Students cannot call faculty or admin procedures; faculty cannot call admin procedures; student assignment, submission, course, and file queries are scoped to the authenticated user; faculty submission access is restricted to owned or assigned courses; and administrator mutations use `adminOnlyProcedure`.

Unauthenticated requests were tested against the live server. `auth.me` returns an anonymous result, administrator API access returns HTTP 401, and direct storage access without a session returns HTTP 401. OAuth callback state mismatch returns HTTP 403. Zod validation limits identifiers, text fields, marks, deadline values, file names, MIME metadata, encoded payloads, file extensions, and file sizes. Students cannot modify marks or evaluations.

The storage proxy was hardened during this review. It now authenticates the request, looks up the requested key against submissions or assignment resources, checks student ownership or faculty course access, returns 404 for unauthorized or unknown objects, and only then obtains a presigned Forge URL. The application UI also uses protected tRPC signed-URL procedures.

A credential-pattern scan found no hard-coded keys in tracked source. The ignored local `.project-config.json` contains environment metadata used by the sandbox; it is not tracked, served, or included in the application bundle. Secret values must remain in the deployment secret manager and must not be copied into source files or tickets.

## UI and UX review

The public landing page uses consistent typography, spacing, color tokens, focusable buttons, and a responsive two-column-to-single-column layout. The authenticated administrator console was visually checked at desktop and mobile widths. The mobile console collapses navigation behind a menu, wraps management tabs, and preserves readable cards and controls. Empty, loading, and data-backed states are present for major dashboards and lists.

Assignment deep-link handling was fixed so links such as `/assignments/:id` return to the assignment workspace and initialize the student detail drawer. Notification links therefore no longer dead-end at the overview page. Notification history uses a responsive popover with unread count, mark-read, and mark-all-read controls.

Provider login and password recovery screens are external Manus UI and were not evaluated as EduSubmit-owned screens. Full authenticated visual review for every role requires provider-backed accounts; the automated real-database workflows cover the role-specific backend paths.

## Performance and deployment review

Dashboard queries are now enabled only when the active route needs them, reducing unnecessary requests for courses, assignments, and calendar data. Large file uploads remain bounded by server-side JSON limits, base64 payload limits, configured assignment size limits, and extension validation. The production bundle is approximately 1.5 MB on disk; Vite reports a JavaScript chunk above 500 kB, which is a performance warning rather than a deployment failure. Code splitting can be a future optimization.

The current deployment uses the standard single Node server with the following commands:

```text
pnpm run build
pnpm start
```

The production smoke test completed successfully. No schema changes were introduced during this QA pass, so the existing migration sequence `0000_sad_wraith` through `0003_pale_leo` remains the database setup baseline.

## Required environment/configuration values

The deployment secret manager must provide these names without committing their values:

- `DATABASE_URL`
- `JWT_SECRET`
- `VITE_APP_ID`
- `OAUTH_SERVER_URL`
- `VITE_OAUTH_PORTAL_URL`
- `OWNER_OPEN_ID`
- `OWNER_NAME`
- `BUILT_IN_FORGE_API_URL`
- `BUILT_IN_FORGE_API_KEY`
- `VITE_FRONTEND_FORGE_API_URL`
- `VITE_FRONTEND_FORGE_API_KEY`

Optional analytics values are `VITE_ANALYTICS_ENDPOINT` and `VITE_ANALYTICS_WEBSITE_ID`.

## Database setup

EduSubmit uses MySQL/TiDB through Drizzle ORM. The live environment already contains the tables and indexes represented by the current schema and migration history, including users/profiles, departments, courses, enrollments, faculty assignments, assignments, submissions, notifications, and announcements. If a new environment is created, apply the generated Drizzle migrations through the WebDev database workflow before starting the application. Do not run destructive schema resets against production data.

## Storage configuration

Files are uploaded through the Manus Forge storage API using `BUILT_IN_FORGE_API_URL` and `BUILT_IN_FORGE_API_KEY`. The database stores object keys and metadata rather than file bytes. Downloads use short-lived presigned URLs or the ownership-checked storage proxy. The storage bucket and Forge credentials must be available to the server runtime; the frontend must not receive the server-side Forge key.

## Authentication configuration

Authentication is Manus OAuth. The frontend constructs the callback from `window.location.origin`, creates a one-time nonce cookie, and passes a signed state payload. The callback verifies the nonce before exchanging the code, synchronizes the user record, and issues an HTTP-only session cookie. The session uses `JWT_SECRET`, `secure` cookies in HTTPS, `SameSite=None`, and a one-year expiration. Role changes must be made through the administrator workflow or a controlled database operation; frontend route visibility is not an authorization mechanism.

## Account creation and role testing

1. Open the deployed EduSubmit URL and select **Sign in**.
2. Complete Manus provider signup or login in the external app-auth portal. Password recovery is handled by Manus on that provider screen.
3. For a Student account, create or provision a Manus user, then ensure the corresponding `users.role` is `student`; assign the student to a course through the Administrator console.
4. For a Faculty account, provision a Manus user, set `users.role` to `faculty`, and assign the faculty member to a course through the Administrator console.
5. For an Admin account, use the configured owner identity or an administrator-created user with `users.role` set to `admin`.
6. Sign out and sign back in as each role. Verify the dashboard, role-specific navigation, assignment scope, and server-side rejection of an unauthorized API call.
7. For a complete submission test, create a future published assignment, enroll a student, upload an allowed file, verify the student confirmation notification, evaluate as faculty, publish marks, and verify the grade and notification appear only for that student.

## Remaining known issues

- Signup and password reset are provider-managed and require a real Manus account for final end-to-end acceptance testing.
- The main JavaScript chunk exceeds Vite's 500 kB advisory threshold; route-level code splitting would improve cold-load performance.
- Full authenticated visual review for independent student and faculty browser sessions requires dedicated provider-backed test accounts.
- Deadline reminders are generated when a user loads notifications; a separate scheduled worker would be needed for proactive delivery before a user opens the app.
