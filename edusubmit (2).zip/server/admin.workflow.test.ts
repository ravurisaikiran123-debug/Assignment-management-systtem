import { afterEach, describe, expect, it } from "vitest";
import { and, eq, inArray } from "drizzle-orm";
import { appRouter } from "./routers";
import { getDb } from "./db";
import { announcements, courseEnrollments, courses, departments, facultyCourseAssignments, users } from "../drizzle/schema";
import type { TrpcContext } from "./_core/context";

const userIds: number[] = [];
const departmentIds: number[] = [];
const courseIds: number[] = [];
const enrollmentIds: number[] = [];
const facultyAssignmentIds: number[] = [];
const announcementIds: number[] = [];

function contextFor(user: any): TrpcContext { return { user, req: { protocol: "https", headers: {} } as TrpcContext["req"], res: { clearCookie: () => undefined } as TrpcContext["res"] }; }

afterEach(async () => {
  const db = await getDb();
  if (!db) return;
  if (announcementIds.length) await db.delete(announcements).where(inArray(announcements.id, announcementIds.splice(0)));
  if (facultyAssignmentIds.length) await db.delete(facultyCourseAssignments).where(inArray(facultyCourseAssignments.id, facultyAssignmentIds.splice(0)));
  if (enrollmentIds.length) await db.delete(courseEnrollments).where(inArray(courseEnrollments.id, enrollmentIds.splice(0)));
  if (courseIds.length) await db.delete(courses).where(inArray(courses.id, courseIds.splice(0)));
  if (departmentIds.length) await db.delete(departments).where(inArray(departments.id, departmentIds.splice(0)));
  if (userIds.length) await db.delete(users).where(inArray(users.id, userIds.splice(0)));
});

describe("administrator portal real database workflow", () => {
  it("manages institution records and rejects non-admin access", async () => {
    const db = await getDb();
    if (!db) throw new Error("DATABASE_URL is required for the admin workflow integration test");
    const suffix = Date.now().toString();
    const adminInsert = await db.insert(users).values({ openId: `admin-workflow-${suffix}`, name: "Workflow Admin", email: `admin-${suffix}@test.local`, role: "admin" });
    const studentInsert = await db.insert(users).values({ openId: `admin-student-${suffix}`, name: "Admin Workflow Student", email: `admin-student-${suffix}@test.local`, role: "student", studentId: `ADM-${suffix}` });
    const facultyInsert = await db.insert(users).values({ openId: `admin-faculty-${suffix}`, name: "Admin Workflow Faculty", email: `admin-faculty-${suffix}@test.local`, role: "faculty", employeeId: `AF-${suffix}` });
    const adminId = Number(adminInsert[0].insertId); const studentId = Number(studentInsert[0].insertId); const facultyId = Number(facultyInsert[0].insertId); userIds.push(adminId, studentId, facultyId);
    const admin = { id: adminId, openId: `admin-workflow-${suffix}`, name: "Workflow Admin", email: `admin-${suffix}@test.local`, loginMethod: "manus", role: "admin", studentId: null, employeeId: null, departmentId: null, yearOfStudy: null, avatarUrl: null, bio: null, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() };
    const student = { ...admin, id: studentId, openId: `admin-student-${suffix}`, name: "Admin Workflow Student", email: `admin-student-${suffix}@test.local`, role: "student", studentId: `ADM-${suffix}` };
    const adminCaller = appRouter.createCaller(contextFor(admin));
    const studentCaller = appRouter.createCaller(contextFor(student));
    await expect(studentCaller.admin.dashboard()).rejects.toMatchObject({ code: "FORBIDDEN" });
    const createdUser = await adminCaller.admin.createUser({ name: "Created Faculty", email: `created-${suffix}@test.local`, role: "faculty", employeeId: `CF-${suffix}` }); userIds.push(createdUser.id);
    const userList = await adminCaller.admin.users({ search: `created-${suffix}` }); expect(userList.some(row => row.id === createdUser.id && row.role === "faculty")).toBe(true);
    const department = await adminCaller.admin.createDepartment({ code: `ADM${suffix.slice(-8)}`, name: "Admin Workflow Department", description: "Test department" }); departmentIds.push(department.id);
    await adminCaller.admin.updateDepartment({ id: department.id, code: `ADU${suffix.slice(-8)}`, name: "Updated Workflow Department", description: "Updated" });
    const course = await adminCaller.admin.createCourse({ code: `AC${suffix.slice(-8)}`, title: "Admin Workflow Course", description: "Test course", credits: 3, departmentId: department.id, semester: "Fall", academicYear: "2026" }); courseIds.push(course.id);
    await adminCaller.admin.assignFaculty({ courseId: course.id, facultyId });
    const facultyAssignment = await db.select({ id: facultyCourseAssignments.id }).from(facultyCourseAssignments).where(and(eq(facultyCourseAssignments.courseId, course.id), eq(facultyCourseAssignments.facultyId, facultyId))).limit(1); if (facultyAssignment[0]) facultyAssignmentIds.push(facultyAssignment[0].id);
    await adminCaller.admin.enrollStudent({ courseId: course.id, studentId });
    const enrollment = await db.select({ id: courseEnrollments.id }).from(courseEnrollments).where(and(eq(courseEnrollments.courseId, course.id), eq(courseEnrollments.studentId, studentId))).limit(1); if (enrollment[0]) enrollmentIds.push(enrollment[0].id);
    const members = await adminCaller.admin.courseMembers({ courseId: course.id }); expect(members.students.some(row => row.id === studentId)).toBe(true); expect(members.faculty.some(row => row.id === facultyId)).toBe(true);
    const announcement = await adminCaller.announcements.create({ title: "Workflow announcement", body: "Admin content", audience: "student" }); announcementIds.push(announcement.id);
    const dashboard = await adminCaller.admin.dashboard(); expect(dashboard.totalDepartments).toBeGreaterThan(0); expect(dashboard.totalCourses).toBeGreaterThan(0);
  }, 15_000);
});
