import { and, asc, desc, eq, like, or, sql } from "drizzle-orm";
import { assignments, courseEnrollments, courses, departments, facultyCourseAssignments, submissions, users } from "../drizzle/schema";
import { getDb } from "./db";

export async function getAdminDashboard() {
  const db = await getDb();
  if (!db) return { totalStudents: 0, totalFaculty: 0, totalDepartments: 0, totalCourses: 0, totalAssignments: 0, totalSubmissions: 0, pendingEvaluations: 0, activity: [] };
  const [students, faculty, departmentRows, courseRows, assignmentRows, submissionRows, pendingRows, activity] = await Promise.all([
    db.select({ count: sql<number>`count(*)` }).from(users).where(eq(users.role, "student")),
    db.select({ count: sql<number>`count(*)` }).from(users).where(eq(users.role, "faculty")),
    db.select({ count: sql<number>`count(*)` }).from(departments),
    db.select({ count: sql<number>`count(*)` }).from(courses),
    db.select({ count: sql<number>`count(*)` }).from(assignments),
    db.select({ count: sql<number>`count(*)` }).from(submissions),
    db.select({ count: sql<number>`count(*)` }).from(submissions).where(sql`${submissions.status} in ('submitted','late')`),
    db.select({ submittedAt: submissions.submittedAt }).from(submissions).orderBy(desc(submissions.submittedAt)).limit(500),
  ]);
  const activityMap = new Map<string, number>();
  for (const row of activity) { const day = new Date(Number(row.submittedAt)).toISOString().slice(0, 10); activityMap.set(day, (activityMap.get(day) ?? 0) + 1); }
  const activitySummary = Array.from(activityMap.entries()).sort((a, b) => b[0].localeCompare(a[0])).slice(0, 7).map(([day, count]) => ({ day, count }));
  return { totalStudents: Number(students[0]?.count ?? 0), totalFaculty: Number(faculty[0]?.count ?? 0), totalDepartments: Number(departmentRows[0]?.count ?? 0), totalCourses: Number(courseRows[0]?.count ?? 0), totalAssignments: Number(assignmentRows[0]?.count ?? 0), totalSubmissions: Number(submissionRows[0]?.count ?? 0), pendingEvaluations: Number(pendingRows[0]?.count ?? 0), activity: activitySummary };
}

export async function listAdminUsers(input?: { search?: string; role?: string }) {
  const db = await getDb();
  if (!db) return [];
  const search = input?.search ? `%${input.search}%` : undefined;
  return db.select({ id: users.id, name: users.name, email: users.email, role: users.role, studentId: users.studentId, employeeId: users.employeeId, departmentId: users.departmentId, departmentName: departments.name, yearOfStudy: users.yearOfStudy, createdAt: users.createdAt, lastSignedIn: users.lastSignedIn }).from(users).leftJoin(departments, eq(users.departmentId, departments.id)).where(and(input?.role && input.role !== "all" ? eq(users.role, input.role) : undefined, search ? or(like(users.name, search), like(users.email, search), like(users.studentId, search), like(users.employeeId, search)) : undefined)).orderBy(desc(users.createdAt)).limit(200);
}

export async function listAdminDepartments(input?: { search?: string }) {
  const db = await getDb();
  if (!db) return [];
  const search = input?.search ? `%${input.search}%` : undefined;
  return db.select({ id: departments.id, code: departments.code, name: departments.name, description: departments.description, createdAt: departments.createdAt, courseCount: sql<number>`count(distinct ${courses.id})` }).from(departments).leftJoin(courses, eq(courses.departmentId, departments.id)).where(search ? or(like(departments.code, search), like(departments.name, search)) : undefined).groupBy(departments.id).orderBy(asc(departments.name));
}

export async function listAdminCourses(input?: { search?: string; departmentId?: number }) {
  const db = await getDb();
  if (!db) return [];
  const search = input?.search ? `%${input.search}%` : undefined;
  return db.select({ id: courses.id, code: courses.code, title: courses.title, description: courses.description, credits: courses.credits, semester: courses.semester, academicYear: courses.academicYear, status: courses.status, departmentId: courses.departmentId, departmentName: departments.name, enrollmentCount: sql<number>`count(distinct ${courseEnrollments.id})`, facultyCount: sql<number>`count(distinct ${facultyCourseAssignments.id})` }).from(courses).leftJoin(departments, eq(courses.departmentId, departments.id)).leftJoin(courseEnrollments, eq(courseEnrollments.courseId, courses.id)).leftJoin(facultyCourseAssignments, eq(facultyCourseAssignments.courseId, courses.id)).where(and(input?.departmentId ? eq(courses.departmentId, input.departmentId) : undefined, search ? or(like(courses.code, search), like(courses.title, search)) : undefined)).groupBy(courses.id, departments.id).orderBy(asc(courses.code));
}

export async function listAdminAssignments(input?: { search?: string; courseId?: number; facultyId?: number; status?: "all" | "draft" | "published" | "closed" }) {
  const db = await getDb();
  if (!db) return [];
  const search = input?.search ? `%${input.search}%` : undefined;
  return db.select({ id: assignments.id, title: assignments.title, dueAt: assignments.dueAt, maxMarks: assignments.maxMarks, status: assignments.status, courseId: courses.id, courseCode: courses.code, courseTitle: courses.title, facultyId: users.id, facultyName: users.name, submissionCount: sql<number>`count(distinct ${submissions.id})`, pendingCount: sql<number>`sum(case when ${submissions.status} in ('submitted','late') then 1 else 0 end)` }).from(assignments).innerJoin(courses, eq(assignments.courseId, courses.id)).innerJoin(users, eq(assignments.facultyId, users.id)).leftJoin(submissions, eq(submissions.assignmentId, assignments.id)).where(and(input?.courseId ? eq(courses.id, input.courseId) : undefined, input?.facultyId ? eq(users.id, input.facultyId) : undefined, input?.status && input.status !== "all" ? eq(assignments.status, input.status) : undefined, search ? or(like(assignments.title, search), like(courses.code, search), like(users.name, search)) : undefined)).groupBy(assignments.id, courses.id, users.id).orderBy(desc(assignments.createdAt));
}

export async function listCourseMembers(courseId: number) {
  const db = await getDb();
  if (!db) return { students: [], faculty: [] };
  const [students, faculty] = await Promise.all([
    db.select({ enrollmentId: courseEnrollments.id, id: users.id, name: users.name, email: users.email, studentId: users.studentId, status: courseEnrollments.status }).from(courseEnrollments).innerJoin(users, eq(courseEnrollments.studentId, users.id)).where(eq(courseEnrollments.courseId, courseId)).orderBy(asc(users.name)),
    db.select({ assignmentId: facultyCourseAssignments.id, id: users.id, name: users.name, email: users.email, employeeId: users.employeeId }).from(facultyCourseAssignments).innerJoin(users, eq(facultyCourseAssignments.facultyId, users.id)).where(eq(facultyCourseAssignments.courseId, courseId)).orderBy(asc(users.name)),
  ]);
  return { students, faculty };
}
