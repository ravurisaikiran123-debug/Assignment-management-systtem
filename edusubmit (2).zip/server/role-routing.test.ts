import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type User = NonNullable<TrpcContext["user"]>;

function contextFor(role: "student" | "faculty" | "admin"): TrpcContext {
  const user: User = {
    id: role === "student" ? 101 : role === "faculty" ? 202 : 303,
    openId: `role-test-${role}`,
    email: `${role}@edusubmit.test`,
    name: `Role Test ${role}`,
    loginMethod: "manus",
    role,
    studentId: role === "student" ? "STU-101" : null,
    employeeId: role !== "student" ? `EMP-${role}` : null,
    departmentId: null,
    yearOfStudy: role === "student" ? 2 : null,
    avatarUrl: null,
    bio: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => undefined } as TrpcContext["res"],
  };
}

describe("role dashboard routing", () => {
  it.each(["student", "faculty", "admin"] as const)("allows %s to read the protected dashboard contract", async (role) => {
    const result = await appRouter.createCaller(contextFor(role)).dashboard.stats();
    expect(result).toHaveProperty("courses");
    expect(result).toHaveProperty("assignments");
  });

  it("rejects faculty from administrator directory access", async () => {
    const caller = appRouter.createCaller(contextFor("faculty"));
    await expect(caller.admin.users()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("rejects students from faculty submission review", async () => {
    const caller = appRouter.createCaller(contextFor("student"));
    await expect(caller.submissions.byAssignment({ assignmentId: 1 })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
