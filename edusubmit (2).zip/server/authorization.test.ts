import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type User = NonNullable<TrpcContext["user"]>;

function contextFor(role: string): TrpcContext {
  const user: User = {
    id: 42,
    openId: `test-${role}`,
    email: `${role}@example.com`,
    name: `Test ${role}`,
    loginMethod: "test",
    role,
    studentId: role === "student" ? "STU-42" : null,
    employeeId: role === "faculty" ? "EMP-42" : null,
    departmentId: null,
    yearOfStudy: null,
    avatarUrl: null,
    bio: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => undefined } as TrpcContext["res"],
  };
}

describe("server-side role authorization", () => {
  it("rejects student access to admin course creation", async () => {
    const caller = appRouter.createCaller(contextFor("student"));
    await expect(caller.admin.createCourse({
      code: "CS-401",
      title: "Secure systems",
      credits: 4,
    })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("rejects student access to faculty grading", async () => {
    const caller = appRouter.createCaller(contextFor("student"));
    await expect(caller.submissions.grade({ id: 1, marks: 90, feedback: "Good work" })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
