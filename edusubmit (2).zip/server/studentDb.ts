import { and, asc, desc, eq, like, or, sql } from "drizzle-orm";
import { assignments, courseEnrollments, courses, submissions, users } from "../drizzle/schema";
import { getDb } from "./db";

export async function getStudentDashboard(userId: number) {
  const db = await getDb();
  if (!db) return { totalAssignments: 0, pendingAssignments: 0, submittedAssignments: 0, gradedAssignments: 0, overdueAssignments: 0, upcomingDeadlines: [], recentSubmissions: [] };
  const now = Date.now();
  const base = and(eq(courseEnrollments.studentId, userId), eq(courseEnrollments.status, "active"), eq(assignments.status, "published"));
  const [total, pending, submitted, graded, overdue, upcomingDeadlines, recentSubmissions] = await Promise.all([
    db.select({ count: sql<number>`count(distinct ${assignments.id})` }).from(courseEnrollments).innerJoin(assignments, eq(assignments.courseId, courseEnrollments.courseId)).where(base),
    db.select({ count: sql<number>`count(distinct ${assignments.id})` }).from(courseEnrollments).innerJoin(assignments, eq(assignments.courseId, courseEnrollments.courseId)).leftJoin(submissions, and(eq(submissions.assignmentId, assignments.id), eq(submissions.studentId, userId))).where(and(base, sql`${submissions.id} is null`)),
    db.select({ count: sql<number>`count(distinct ${submissions.id})` }).from(submissions).where(eq(submissions.studentId, userId)),
    db.select({ count: sql<number>`count(distinct ${submissions.id})` }).from(submissions).where(and(eq(submissions.studentId, userId), sql`${submissions.status} in ('graded','returned')`)),
    db.select({ count: sql<number>`count(distinct ${assignments.id})` }).from(courseEnrollments).innerJoin(assignments, eq(assignments.courseId, courseEnrollments.courseId)).leftJoin(submissions, and(eq(submissions.assignmentId, assignments.id), eq(submissions.studentId, userId))).where(and(base, sql`${assignments.dueAt} < ${now}`, sql`${submissions.id} is null`)),
    db.select({ id: assignments.id, title: assignments.title, dueAt: assignments.dueAt, maxMarks: assignments.maxMarks, courseCode: courses.code, courseTitle: courses.title, submissionStatus: submissions.status }).from(courseEnrollments).innerJoin(courses, eq(courseEnrollments.courseId, courses.id)).innerJoin(assignments, eq(assignments.courseId, courses.id)).leftJoin(submissions, and(eq(submissions.assignmentId, assignments.id), eq(submissions.studentId, userId))).where(and(base, sql`${assignments.dueAt} >= ${now}`)).orderBy(asc(assignments.dueAt)).limit(5),
    db.select({ id: submissions.id, assignmentId: submissions.assignmentId, assignmentTitle: assignments.title, courseCode: courses.code, fileName: submissions.fileName, submittedAt: submissions.submittedAt, status: submissions.status, marks: submissions.marks, maxMarks: assignments.maxMarks }).from(submissions).innerJoin(assignments, eq(submissions.assignmentId, assignments.id)).innerJoin(courses, eq(assignments.courseId, courses.id)).where(eq(submissions.studentId, userId)).orderBy(desc(submissions.submittedAt)).limit(5),
  ]);
  return { totalAssignments: Number(total[0]?.count ?? 0), pendingAssignments: Number(pending[0]?.count ?? 0), submittedAssignments: Number(submitted[0]?.count ?? 0), gradedAssignments: Number(graded[0]?.count ?? 0), overdueAssignments: Number(overdue[0]?.count ?? 0), upcomingDeadlines, recentSubmissions };
}

export async function listStudentAssignments(userId: number, input: { search?: string; courseId?: number; status?: "all" | "pending" | "submitted" | "graded" | "overdue"; sort?: "deadline_asc" | "deadline_desc" }) {
  const db = await getDb();
  if (!db) return [];
  const searchFilter = input.search ? or(like(assignments.title, `%${input.search}%`), like(courses.code, `%${input.search}%`), like(courses.title, `%${input.search}%`)) : undefined;
  const courseFilter = input.courseId ? eq(courses.id, input.courseId) : undefined;
  const now = Date.now();
  const statusFilter = input.status === "pending" ? sql`${submissions.id} is null and ${assignments.dueAt} >= ${now}` : input.status === "submitted" ? and(sql`${submissions.id} is not null`, sql`${submissions.status} not in ('graded','returned')`) : input.status === "graded" ? sql`${submissions.status} in ('graded','returned')` : input.status === "overdue" ? and(sql`${submissions.id} is null`, sql`${assignments.dueAt} < ${now}`) : undefined;
  return db.select({ id: assignments.id, title: assignments.title, description: assignments.description, instructions: assignments.instructions, dueAt: assignments.dueAt, maxMarks: assignments.maxMarks, status: assignments.status, questionFileKey: assignments.questionFileKey, questionFileName: assignments.questionFileName, courseId: courses.id, courseCode: courses.code, courseTitle: courses.title, submissionId: submissions.id, submissionStatus: submissions.status, submittedAt: submissions.submittedAt, marks: submissions.marks, feedback: submissions.feedback }).from(courseEnrollments).innerJoin(courses, eq(courseEnrollments.courseId, courses.id)).innerJoin(assignments, eq(assignments.courseId, courses.id)).leftJoin(submissions, and(eq(submissions.assignmentId, assignments.id), eq(submissions.studentId, userId))).where(and(eq(courseEnrollments.studentId, userId), eq(courseEnrollments.status, "active"), eq(assignments.status, "published"), searchFilter, courseFilter, statusFilter)).orderBy(input.sort === "deadline_desc" ? desc(assignments.dueAt) : asc(assignments.dueAt));
}

export async function getStudentAssignmentDetails(userId: number, assignmentId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select({ id: assignments.id, title: assignments.title, description: assignments.description, instructions: assignments.instructions, dueAt: assignments.dueAt, maxMarks: assignments.maxMarks, status: assignments.status, questionFileKey: assignments.questionFileKey, questionFileName: assignments.questionFileName, courseId: courses.id, courseCode: courses.code, courseTitle: courses.title, facultyId: users.id, facultyName: users.name, facultyEmail: users.email, submissionId: submissions.id, submissionStatus: submissions.status, submittedAt: submissions.submittedAt, fileName: submissions.fileName, marks: submissions.marks, feedback: submissions.feedback }).from(courseEnrollments).innerJoin(courses, eq(courseEnrollments.courseId, courses.id)).innerJoin(assignments, eq(assignments.courseId, courses.id)).innerJoin(users, eq(assignments.facultyId, users.id)).leftJoin(submissions, and(eq(submissions.assignmentId, assignments.id), eq(submissions.studentId, userId))).where(and(eq(courseEnrollments.studentId, userId), eq(courseEnrollments.status, "active"), eq(assignments.id, assignmentId), eq(assignments.status, "published"))).limit(1);
  return rows[0];
}

export async function listStudentSubmissions(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({ id: submissions.id, assignmentId: submissions.assignmentId, assignmentTitle: assignments.title, courseId: courses.id, courseCode: courses.code, courseTitle: courses.title, fileKey: submissions.fileKey, fileName: submissions.fileName, submissionText: submissions.submissionText, submittedAt: submissions.submittedAt, status: submissions.status, marks: submissions.marks, feedback: submissions.feedback, maxMarks: assignments.maxMarks, evaluatedAt: submissions.gradedAt }).from(submissions).innerJoin(assignments, eq(submissions.assignmentId, assignments.id)).innerJoin(courses, eq(assignments.courseId, courses.id)).where(eq(submissions.studentId, userId)).orderBy(desc(submissions.submittedAt));
}
