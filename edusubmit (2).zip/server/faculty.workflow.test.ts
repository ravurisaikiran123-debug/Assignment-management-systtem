import { afterEach, describe, expect, it } from "vitest";
import { and, eq, inArray } from "drizzle-orm";
import { appRouter } from "./routers";
import { getDb } from "./db";
import { assignments, courseEnrollments, courses, facultyCourseAssignments, notifications, submissions, users } from "../drizzle/schema";
import type { TrpcContext } from "./_core/context";

const usersToDelete: number[] = [];
const coursesToDelete: number[] = [];
const assignmentsToDelete: number[] = [];
const submissionsToDelete: number[] = [];

function contextFor(user: any): TrpcContext { return { user, req: { protocol: "https", headers: {} } as TrpcContext["req"], res: { clearCookie: () => undefined } as TrpcContext["res"] }; }

afterEach(async () => {
  const db = await getDb();
  if (!db) return;
  if (submissionsToDelete.length) await db.delete(submissions).where(inArray(submissions.id, submissionsToDelete.splice(0)));
  if (assignmentsToDelete.length) await db.delete(assignments).where(inArray(assignments.id, assignmentsToDelete.splice(0)));
  if (coursesToDelete.length) {
    await db.delete(facultyCourseAssignments).where(inArray(facultyCourseAssignments.courseId, coursesToDelete));
    await db.delete(courseEnrollments).where(inArray(courseEnrollments.courseId, coursesToDelete));
    await db.delete(courses).where(inArray(courses.id, coursesToDelete.splice(0)));
  }
  if (usersToDelete.length) {
    await db.delete(notifications).where(inArray(notifications.userId, usersToDelete));
    await db.delete(users).where(inArray(users.id, usersToDelete.splice(0)));
  }
});

describe("faculty portal real database workflow", () => {
  it("creates, reviews, evaluates, and publishes marks only within the faculty assignment scope", async () => {
    const db = await getDb();
    if (!db) throw new Error("DATABASE_URL is required for the faculty workflow integration test");
    const suffix = Date.now().toString();
    const facultyInsert = await db.insert(users).values({ openId: `faculty-workflow-${suffix}`, name: "Workflow Faculty", email: `faculty-${suffix}@test.local`, role: "faculty" });
    const studentInsert = await db.insert(users).values({ openId: `student-workflow-${suffix}`, name: "Workflow Student", email: `student-${suffix}@test.local`, role: "student", studentId: `WF-${suffix}` });
    const otherFacultyInsert = await db.insert(users).values({ openId: `other-faculty-${suffix}`, name: "Other Faculty", email: `other-faculty-${suffix}@test.local`, role: "faculty" });
    const facultyId = Number(facultyInsert[0].insertId); const studentId = Number(studentInsert[0].insertId); const otherFacultyId = Number(otherFacultyInsert[0].insertId); usersToDelete.push(facultyId, studentId, otherFacultyId);
    const courseInsert = await db.insert(courses).values({ code: `FW${suffix.slice(-10)}`, title: "Faculty Workflow Course", credits: 4, status: "active", createdById: facultyId });
    const courseId = Number(courseInsert[0].insertId); coursesToDelete.push(courseId);
    await db.insert(facultyCourseAssignments).values({ courseId, facultyId });
    await db.insert(courseEnrollments).values({ courseId, studentId, status: "active" });
    const faculty = { id: facultyId, openId: `faculty-workflow-${suffix}`, name: "Workflow Faculty", email: `faculty-${suffix}@test.local`, loginMethod: "manus", role: "faculty", studentId: null, employeeId: `EMP-${suffix}`, departmentId: null, yearOfStudy: null, avatarUrl: null, bio: null, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() };
    const student = { id: studentId, openId: `student-workflow-${suffix}`, name: "Workflow Student", email: `student-${suffix}@test.local`, loginMethod: "manus", role: "student", studentId: `WF-${suffix}`, employeeId: null, departmentId: null, yearOfStudy: 1, avatarUrl: null, bio: null, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() };
    const otherFaculty = { ...faculty, id: otherFacultyId, openId: `other-faculty-${suffix}`, email: `other-faculty-${suffix}@test.local`, name: "Other Faculty", employeeId: `OTHER-${suffix}` };
    const facultyCaller = appRouter.createCaller(contextFor(faculty));
    const studentCaller = appRouter.createCaller(contextFor(student));
    const otherFacultyCaller = appRouter.createCaller(contextFor(otherFaculty));
    const created = await facultyCaller.assignments.create({ courseId, title: "Workflow Assignment", description: "Faculty-created work", instructions: "Submit a PDF", dueAt: Date.now() + 86_400_000, maxMarks: 100, allowedFileTypes: "pdf", fileSizeLimit: 5_000_000, status: "published" });
    assignmentsToDelete.push(created.id);
    expect((await facultyCaller.assignments.facultyList({ status: "published" })).some(row => row.id === created.id)).toBe(true);
    await expect(otherFacultyCaller.assignments.update({ id: created.id, title: "Unauthorized edit" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    const submissionInsert = await db.insert(submissions).values({ assignmentId: created.id, studentId, fileKey: `workflow/${suffix}.pdf`, fileName: "workflow.pdf", fileSize: 100, mimeType: "application/pdf", submissionText: "My submission", submittedAt: Date.now(), status: "submitted" });
    const submissionId = Number(submissionInsert[0].insertId); submissionsToDelete.push(submissionId);
    const queue = await facultyCaller.submissions.facultyList({ assignmentId: created.id });
    expect(queue[0]?.studentId).toBe(`WF-${suffix}`);
    await facultyCaller.submissions.evaluate({ id: submissionId, marks: 92, feedback: "Strong work." });
    expect((await studentCaller.submissions.mine()).find(row => row.id === submissionId)?.marks).toBe(92);
    await facultyCaller.submissions.publishGrade({ id: submissionId });
    const published = await db.select({ status: submissions.status }).from(submissions).where(eq(submissions.id, submissionId)).limit(1);
    expect(published[0]?.status).toBe("graded");
    const gradeNotice = await db.select({ title: notifications.title }).from(notifications).where(and(eq(notifications.userId, studentId), eq(notifications.type, "grade"))).limit(1);
    expect(gradeNotice[0]?.title).toBe("Assignment graded");
  }, 15_000);
});
