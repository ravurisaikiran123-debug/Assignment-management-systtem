import { and, asc, desc, eq, gte, like, lte, or, sql } from "drizzle-orm";
import { assignments, courseEnrollments, courses, facultyCourseAssignments, notifications, submissions, users } from "../drizzle/schema";
import { getDb } from "./db";

export async function listCalendarAssignments(userId: number, role: string, input: { month?: string; courseId?: number }) {
  const db = await getDb();
  if (!db) return [];
  const start = input.month ? new Date(`${input.month}-01T00:00:00`).getTime() : Date.now();
  const end = input.month ? new Date(new Date(`${input.month}-01T00:00:00`).getFullYear(), new Date(`${input.month}-01T00:00:00`).getMonth() + 1, 0, 23, 59, 59, 999).getTime() : start + 1000 * 60 * 60 * 24 * 90;
  const dateFilter = and(gte(assignments.dueAt, start), lte(assignments.dueAt, end), input.courseId ? eq(courses.id, input.courseId) : undefined);
  if (role === "student") return db.select({ id: assignments.id, title: assignments.title, dueAt: assignments.dueAt, status: assignments.status, courseId: courses.id, courseCode: courses.code, courseTitle: courses.title, maxMarks: assignments.maxMarks, submissionStatus: submissions.status }).from(courseEnrollments).innerJoin(courses, eq(courseEnrollments.courseId, courses.id)).innerJoin(assignments, eq(assignments.courseId, courses.id)).leftJoin(submissions, and(eq(submissions.assignmentId, assignments.id), eq(submissions.studentId, userId))).where(and(dateFilter, eq(courseEnrollments.studentId, userId), eq(courseEnrollments.status, "active"), eq(assignments.status, "published"))).orderBy(asc(assignments.dueAt));
  if (role === "faculty") return db.select({ id: assignments.id, title: assignments.title, dueAt: assignments.dueAt, status: assignments.status, courseId: courses.id, courseCode: courses.code, courseTitle: courses.title, maxMarks: assignments.maxMarks }).from(assignments).innerJoin(courses, eq(assignments.courseId, courses.id)).where(and(dateFilter, eq(assignments.facultyId, userId))).orderBy(asc(assignments.dueAt));
  return db.select({ id: assignments.id, title: assignments.title, dueAt: assignments.dueAt, status: assignments.status, courseId: courses.id, courseCode: courses.code, courseTitle: courses.title, maxMarks: assignments.maxMarks }).from(assignments).innerJoin(courses, eq(assignments.courseId, courses.id)).where(dateFilter).orderBy(asc(assignments.dueAt));
}

export async function getNotificationCenter(userId: number, limit = 100) {
  const db = await getDb();
  if (!db) return { items: [], unread: 0 };
  const [items, unread] = await Promise.all([
    db.select().from(notifications).where(eq(notifications.userId, userId)).orderBy(desc(notifications.createdAt)).limit(Math.min(limit, 200)),
    db.select({ count: sql<number>`count(*)` }).from(notifications).where(and(eq(notifications.userId, userId), sql`${notifications.readAt} is null`)),
  ]);
  return { items, unread: Number(unread[0]?.count ?? 0) };
}

export async function ensureDeadlineNotifications(userId: number, role: string) {
  const db = await getDb();
  if (!db) return;
  const now = Date.now(); const soon = now + 48 * 60 * 60 * 1000;
  const rows = role === "student"
    ? await db.select({ id: assignments.id, title: assignments.title, dueAt: assignments.dueAt, courseId: assignments.courseId }).from(courseEnrollments).innerJoin(assignments, eq(assignments.courseId, courseEnrollments.courseId)).where(and(eq(courseEnrollments.studentId, userId), eq(courseEnrollments.status, "active"), eq(assignments.status, "published"), gte(assignments.dueAt, now), lte(assignments.dueAt, soon)))
    : role === "faculty"
      ? await db.select({ id: assignments.id, title: assignments.title, dueAt: assignments.dueAt, courseId: assignments.courseId }).from(assignments).where(and(eq(assignments.facultyId, userId), eq(assignments.status, "published"), gte(assignments.dueAt, now), lte(assignments.dueAt, soon)))
      : [];
  for (const row of rows) {
    const relatedUrl = `/assignments/${row.id}`;
    const existing = await db.select({ id: notifications.id }).from(notifications).where(and(eq(notifications.userId, userId), eq(notifications.type, "deadline"), eq(notifications.relatedUrl, relatedUrl))).limit(1);
    if (!existing[0]) await db.insert(notifications).values({ userId, type: "deadline", title: "Deadline approaching", body: `${row.title} is due within 48 hours.`, relatedUrl, createdAt: Date.now() });
  }
}

export async function getStudentAnalytics(userId: number) {
  const db = await getDb();
  if (!db) return { completionRate: 0, statusSummary: [], coursePerformance: [] };
  const [totals, statuses, coursesData] = await Promise.all([
    db.select({ total: sql<number>`count(distinct ${assignments.id})`, submitted: sql<number>`count(distinct case when ${submissions.id} is not null then ${assignments.id} end)` }).from(courseEnrollments).innerJoin(assignments, eq(assignments.courseId, courseEnrollments.courseId)).leftJoin(submissions, and(eq(submissions.assignmentId, assignments.id), eq(submissions.studentId, userId))).where(and(eq(courseEnrollments.studentId, userId), eq(courseEnrollments.status, "active"), eq(assignments.status, "published"))),
    db.select({ status: sql<string>`case when ${submissions.id} is null and ${assignments.dueAt} < ${Date.now()} then 'overdue' when ${submissions.status} in ('graded','returned') then 'graded' when ${submissions.id} is not null then 'submitted' else 'pending' end`, count: sql<number>`count(distinct ${assignments.id})` }).from(courseEnrollments).innerJoin(assignments, eq(assignments.courseId, courseEnrollments.courseId)).leftJoin(submissions, and(eq(submissions.assignmentId, assignments.id), eq(submissions.studentId, userId))).where(and(eq(courseEnrollments.studentId, userId), eq(courseEnrollments.status, "active"), eq(assignments.status, "published"))).groupBy(sql`case when ${submissions.id} is null and ${assignments.dueAt} < ${Date.now()} then 'overdue' when ${submissions.status} in ('graded','returned') then 'graded' when ${submissions.id} is not null then 'submitted' else 'pending' end`),
    db.select({ courseId: courses.id, courseCode: courses.code, courseTitle: courses.title, average: sql<number>`coalesce(round(avg(${submissions.marks} / nullif(${assignments.maxMarks}, 0) * 100), 1), 0)`, submitted: sql<number>`count(${submissions.id})` }).from(courseEnrollments).innerJoin(courses, eq(courseEnrollments.courseId, courses.id)).innerJoin(assignments, eq(assignments.courseId, courses.id)).leftJoin(submissions, and(eq(submissions.assignmentId, assignments.id), eq(submissions.studentId, userId))).where(and(eq(courseEnrollments.studentId, userId), eq(courseEnrollments.status, "active"), eq(assignments.status, "published"))).groupBy(courses.id),
  ]);
  const total = Number(totals[0]?.total ?? 0); const submitted = Number(totals[0]?.submitted ?? 0);
  return { completionRate: total ? Math.round((submitted / total) * 100) : 0, statusSummary: statuses.map(row => ({ status: row.status, count: Number(row.count ?? 0) })), coursePerformance: coursesData.map(row => ({ ...row, average: Number(row.average ?? 0), submitted: Number(row.submitted ?? 0) })) };
}

export async function getFacultyAnalytics(facultyId: number) {
  const db = await getDb();
  if (!db) return { submissionRate: 0, pendingEvaluations: 0, courses: [] };
  const [totals, coursesData, pending] = await Promise.all([
    db.select({ assignments: sql<number>`count(distinct ${assignments.id})`, submissions: sql<number>`count(${submissions.id})` }).from(assignments).leftJoin(submissions, eq(submissions.assignmentId, assignments.id)).where(eq(assignments.facultyId, facultyId)),
    db.select({ courseId: courses.id, courseCode: courses.code, courseTitle: courses.title, assignments: sql<number>`count(distinct ${assignments.id})`, submissions: sql<number>`count(${submissions.id})`, pending: sql<number>`sum(case when ${submissions.status} in ('submitted','late') then 1 else 0 end)` }).from(assignments).innerJoin(courses, eq(assignments.courseId, courses.id)).leftJoin(submissions, eq(submissions.assignmentId, assignments.id)).where(eq(assignments.facultyId, facultyId)).groupBy(courses.id),
    db.select({ count: sql<number>`count(*)` }).from(assignments).innerJoin(submissions, eq(submissions.assignmentId, assignments.id)).where(and(eq(assignments.facultyId, facultyId), sql`${submissions.status} in ('submitted','late')`)),
  ]);
  const totalAssignments = Number(totals[0]?.assignments ?? 0); const totalSubmissions = Number(totals[0]?.submissions ?? 0);
  return { submissionRate: totalAssignments ? Math.round((totalSubmissions / totalAssignments) * 100) : 0, pendingEvaluations: Number(pending[0]?.count ?? 0), courses: coursesData.map(row => ({ ...row, assignments: Number(row.assignments ?? 0), submissions: Number(row.submissions ?? 0), pending: Number(row.pending ?? 0) })) };
}

export async function getAdminAnalytics() {
  const db = await getDb();
  if (!db) return { assignmentStats: [], courseStats: [] };
  const [assignmentStats, courseStats] = await Promise.all([
    db.select({ status: assignments.status, count: sql<number>`count(*)`, submissions: sql<number>`count(${submissions.id})` }).from(assignments).leftJoin(submissions, eq(submissions.assignmentId, assignments.id)).groupBy(assignments.status),
    db.select({ courseId: courses.id, courseCode: courses.code, courseTitle: courses.title, assignments: sql<number>`count(distinct ${assignments.id})`, submissions: sql<number>`count(${submissions.id})` }).from(courses).leftJoin(assignments, eq(assignments.courseId, courses.id)).leftJoin(submissions, eq(submissions.assignmentId, assignments.id)).groupBy(courses.id),
  ]);
  return { assignmentStats: assignmentStats.map(row => ({ ...row, count: Number(row.count ?? 0), submissions: Number(row.submissions ?? 0) })), courseStats: courseStats.map(row => ({ ...row, assignments: Number(row.assignments ?? 0), submissions: Number(row.submissions ?? 0) })) };
}

export async function getSubmissionTimeline(userId: number, assignmentId: number) {
  const db = await getDb();
  if (!db) return [];
  const row = await db.select({ assignment: assignments, submission: submissions }).from(assignments).leftJoin(submissions, and(eq(submissions.assignmentId, assignments.id), eq(submissions.studentId, userId))).where(eq(assignments.id, assignmentId)).limit(1);
  if (!row[0]) return [];
  const events = [{ key: "published", label: "Assignment published", at: row[0].assignment.createdAt ? new Date(row[0].assignment.createdAt).getTime() : null, done: row[0].assignment.status === "published" || row[0].assignment.status === "closed" }, { key: "uploaded", label: "Submission uploaded", at: row[0].submission?.submittedAt ?? null, done: Boolean(row[0].submission) }, { key: "received", label: "Submission received", at: row[0].submission?.submittedAt ?? null, done: Boolean(row[0].submission) }, { key: "pending", label: "Evaluation pending", at: row[0].submission?.submittedAt ?? null, done: Boolean(row[0].submission) }, { key: "graded", label: "Marks published", at: row[0].submission?.gradedAt ?? null, done: row[0].submission?.status === "graded" || row[0].submission?.status === "returned" }];
  return events;
}
