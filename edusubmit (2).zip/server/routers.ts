import { COOKIE_NAME } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { and, asc, desc, eq, sql } from "drizzle-orm";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";
import {
  announcements,
  assignments,
  courseEnrollments,
  courses,
  createNotification,
  departments,
  facultyCourseAssignments,
  facultyHasCourseAccess,
  getDashboardStats,
  getDb,
  getFacultySubmissionDetail,
  getProfileById,
  getUserById,
  listAnnouncements,
  listAssignmentsForUser,
  listCoursesForUser,
  listNotifications,
  notifyCourseStudents,
  notifications,
  submissions,
  users,
} from "./db";
import { storageGetSignedUrl, storagePut } from "./storage";
import { getStudentAssignmentDetails, getStudentDashboard, listStudentAssignments, listStudentSubmissions } from "./studentDb";
import { getFacultyDashboard, listFacultyAssignments, listFacultySubmissions } from "./facultyDb";
import { getAdminDashboard, listAdminAssignments, listAdminCourses, listAdminDepartments, listAdminUsers, listCourseMembers } from "./adminDb";
import { ensureDeadlineNotifications, getAdminAnalytics, getFacultyAnalytics, getNotificationCenter, getStudentAnalytics, getSubmissionTimeline, listCalendarAssignments } from "./advancedDb";

const roleProcedure = (...roles: string[]) => protectedProcedure.use(({ ctx, next }) => {
  if (!roles.includes(ctx.user.role)) throw new TRPCError({ code: "FORBIDDEN", message: "Your role cannot perform this action." });
  return next({ ctx });
});
const studentProcedure = roleProcedure("student");
const facultyProcedure = roleProcedure("faculty", "admin");
const adminOnlyProcedure = roleProcedure("admin");

const fileSchema = z.object({
  fileName: z.string().min(1).max(255),
  fileBase64: z.string().min(1).max(14_000_000),
  mimeType: z.string().min(1).max(120),
  fileSize: z.number().int().positive().max(10_000_000),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    profile: protectedProcedure.query(({ ctx }) => getProfileById(ctx.user.id)),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
    updateProfile: protectedProcedure.input(z.object({ name: z.string().min(2).max(120), bio: z.string().max(600).optional(), departmentId: z.number().int().positive().optional(), yearOfStudy: z.number().int().min(1).max(8).optional() })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
      await db.update(users).set({ name: input.name, bio: input.bio ?? null, departmentId: input.departmentId ?? null, yearOfStudy: input.yearOfStudy ?? null }).where(eq(users.id, ctx.user.id));
      return getUserById(ctx.user.id);
    }),
  }),
  dashboard: router({
    stats: protectedProcedure.query(({ ctx }) => getDashboardStats(ctx.user.id, ctx.user.role)),
    student: studentProcedure.query(({ ctx }) => getStudentDashboard(ctx.user.id)),
    faculty: facultyProcedure.query(({ ctx }) => getFacultyDashboard(ctx.user.id)),
    calendar: protectedProcedure.input(z.object({ month: z.string().regex(/^\d{4}-\d{2}$/).optional(), courseId: z.number().int().positive().optional() }).optional()).query(({ ctx, input }) => listCalendarAssignments(ctx.user.id, ctx.user.role, input ?? {})),
    analytics: protectedProcedure.query(async ({ ctx }) => { if (ctx.user.role === "student") return getStudentAnalytics(ctx.user.id); if (ctx.user.role === "faculty") return getFacultyAnalytics(ctx.user.id); return getAdminAnalytics(); }),
  }),
  courses: router({
    list: protectedProcedure.input(z.object({ search: z.string().optional() }).optional()).query(async ({ ctx, input }) => {
      const rows = await listCoursesForUser(ctx.user.id, ctx.user.role);
      if (!input?.search) return rows;
      const q = input.search.toLowerCase();
      return rows.filter((course: any) => `${course.code} ${course.title}`.toLowerCase().includes(q));
    }),
    details: protectedProcedure.input(z.object({ id: z.number().int().positive() })).query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      if (ctx.user.role === "student") {
        const enrolled = await db.select({ id: courseEnrollments.id }).from(courseEnrollments).where(and(eq(courseEnrollments.courseId, input.id), eq(courseEnrollments.studentId, ctx.user.id), eq(courseEnrollments.status, "active"))).limit(1);
        if (!enrolled[0]) throw new TRPCError({ code: "FORBIDDEN", message: "You are not enrolled in this course." });
      }
      if (ctx.user.role === "faculty") {
        const assigned = await db.select({ id: facultyCourseAssignments.id }).from(facultyCourseAssignments).where(and(eq(facultyCourseAssignments.courseId, input.id), eq(facultyCourseAssignments.facultyId, ctx.user.id))).limit(1);
        if (!assigned[0]) throw new TRPCError({ code: "FORBIDDEN", message: "You are not assigned to this course." });
      }
      const course = await db.select().from(courses).where(eq(courses.id, input.id)).limit(1);
      if (!course[0]) throw new TRPCError({ code: "NOT_FOUND", message: "Course not found" });
      const assignmentRows = await db.select().from(assignments).where(eq(assignments.courseId, input.id)).orderBy(desc(assignments.createdAt));
      return { course: course[0], assignments: assignmentRows };
    }),
  }),
  assignments: router({
    list: protectedProcedure.input(z.object({ search: z.string().optional() }).optional()).query(({ ctx, input }) => listAssignmentsForUser(ctx.user.id, ctx.user.role, input?.search)),
    studentList: studentProcedure.input(z.object({ search: z.string().optional(), courseId: z.number().int().positive().optional(), status: z.enum(["all", "pending", "submitted", "graded", "overdue"]).default("all"), sort: z.enum(["deadline_asc", "deadline_desc"]).default("deadline_asc") })).query(({ ctx, input }) => listStudentAssignments(ctx.user.id, input)),
    studentDetails: studentProcedure.input(z.object({ id: z.number().int().positive() })).query(async ({ ctx, input }) => {
      const row = await getStudentAssignmentDetails(ctx.user.id, input.id);
      if (!row) throw new TRPCError({ code: "NOT_FOUND", message: "Assignment not found in your enrolled courses." });
      return row;
    }),
    facultyList: facultyProcedure.input(z.object({ search: z.string().optional(), courseId: z.number().int().positive().optional(), status: z.enum(["all", "draft", "published", "closed"]).default("all") })).query(({ ctx, input }) => listFacultyAssignments(ctx.user.id, input)),
    create: facultyProcedure.input(z.object({ courseId: z.number().int().positive(), title: z.string().min(3).max(180), description: z.string().max(1200).optional(), instructions: z.string().max(5000).optional(), dueAt: z.number().int().positive(), maxMarks: z.number().int().min(1).max(1000), allowedFileTypes: z.string().min(1).max(500).default("pdf,doc,docx,txt,zip"), fileSizeLimit: z.number().int().min(100_000).max(10_000_000).default(10_000_000), status: z.enum(["draft", "published"]).default("draft"), question: fileSchema.optional() })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      if (ctx.user.role === "faculty") {
        const assigned = await db.select({ id: facultyCourseAssignments.id }).from(facultyCourseAssignments).where(and(eq(facultyCourseAssignments.courseId, input.courseId), eq(facultyCourseAssignments.facultyId, ctx.user.id))).limit(1);
        if (!assigned[0]) throw new TRPCError({ code: "FORBIDDEN", message: "You are not assigned to this course." });
      }
      if (input.dueAt <= Date.now()) throw new TRPCError({ code: "BAD_REQUEST", message: "Deadline must be in the future." });
      let fileKey: string | undefined;
      if (input.question) {
        const uploaded = await storagePut(`assignments/${ctx.user.id}/${input.question.fileName}`, Buffer.from(input.question.fileBase64, "base64"), input.question.mimeType);
        fileKey = uploaded.key;
      }
      const result = await db.insert(assignments).values({ courseId: input.courseId, facultyId: ctx.user.id, title: input.title, description: input.description, instructions: input.instructions, dueAt: input.dueAt, maxMarks: input.maxMarks, allowedFileTypes: input.allowedFileTypes, fileSizeLimit: input.fileSizeLimit, status: input.status, questionFileKey: fileKey, questionFileName: input.question?.fileName });
      const id = Number(result[0].insertId);
      if (input.status === "published") await notifyCourseStudents(input.courseId, "assignment", `New assignment: ${input.title}`, "A new assignment is available in your course workspace.", `/assignments/${id}`);
      return { id };
    }),
    update: facultyProcedure.input(z.object({ id: z.number().int().positive(), title: z.string().min(3).max(180).optional(), description: z.string().max(1200).optional(), instructions: z.string().max(5000).optional(), dueAt: z.number().int().positive().optional(), maxMarks: z.number().int().min(1).max(1000).optional(), allowedFileTypes: z.string().min(1).max(500).optional(), fileSizeLimit: z.number().int().min(100_000).max(10_000_000).optional() })).mutation(async ({ ctx, input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const row = await db.select().from(assignments).where(eq(assignments.id, input.id)).limit(1);
      if (!row[0] || (ctx.user.role === "faculty" && row[0].facultyId !== ctx.user.id)) throw new TRPCError({ code: "FORBIDDEN" });
      if (row[0].status === "closed") throw new TRPCError({ code: "BAD_REQUEST", message: "Closed assignments cannot be edited." });
      if (input.dueAt !== undefined && input.dueAt <= Date.now()) throw new TRPCError({ code: "BAD_REQUEST", message: "Deadline must be in the future." });
      const { id: _id, ...changes } = input; await db.update(assignments).set(changes).where(eq(assignments.id, input.id)); return { success: true };
    }),
    close: facultyProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const row = await db.select().from(assignments).where(eq(assignments.id, input.id)).limit(1);
      if (!row[0] || (ctx.user.role === "faculty" && row[0].facultyId !== ctx.user.id)) throw new TRPCError({ code: "FORBIDDEN" });
      await db.update(assignments).set({ status: "closed" }).where(eq(assignments.id, input.id)); return { success: true };
    }),
    delete: facultyProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const row = await db.select().from(assignments).where(eq(assignments.id, input.id)).limit(1);
      if (!row[0] || (ctx.user.role === "faculty" && row[0].facultyId !== ctx.user.id)) throw new TRPCError({ code: "FORBIDDEN" });
      const existing = await db.select({ id: submissions.id }).from(submissions).where(eq(submissions.assignmentId, input.id)).limit(1);
      if (row[0].status !== "draft" || existing[0]) throw new TRPCError({ code: "BAD_REQUEST", message: "Only empty draft assignments can be deleted." });
      await db.delete(assignments).where(eq(assignments.id, input.id)); return { success: true };
    }),
    extend: facultyProcedure.input(z.object({ id: z.number().int().positive(), dueAt: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const row = await db.select().from(assignments).where(eq(assignments.id, input.id)).limit(1);
      if (!row[0] || (ctx.user.role === "faculty" && row[0].facultyId !== ctx.user.id)) throw new TRPCError({ code: "FORBIDDEN" });
      if (input.dueAt <= row[0].dueAt) throw new TRPCError({ code: "BAD_REQUEST", message: "An extension must be later than the current deadline." });
      await db.update(assignments).set({ dueAt: input.dueAt }).where(eq(assignments.id, input.id));
      await notifyCourseStudents(row[0].courseId, "deadline_extended", `Deadline extended: ${row[0].title}`, `The deadline is now ${new Date(input.dueAt).toLocaleString()}.`, `/assignments/${input.id}`);
      return { success: true };
    }),
    publish: facultyProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const assignment = await db.select().from(assignments).where(eq(assignments.id, input.id)).limit(1);
      if (!assignment[0] || (ctx.user.role === "faculty" && assignment[0].facultyId !== ctx.user.id)) throw new TRPCError({ code: "FORBIDDEN" });
      await db.update(assignments).set({ status: "published" }).where(eq(assignments.id, input.id));
      await notifyCourseStudents(assignment[0].courseId, "assignment", `New assignment: ${assignment[0].title}`, "A new assignment is available in your course workspace.", `/assignments/${input.id}`);
      return { success: true };
    }),
    questionUrl: protectedProcedure.input(z.object({ id: z.number().int().positive() })).query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const assignment = await db.select().from(assignments).where(eq(assignments.id, input.id)).limit(1);
      if (!assignment[0]?.questionFileKey || (ctx.user.role === "student" && assignment[0].status !== "published")) throw new TRPCError({ code: "NOT_FOUND", message: "No question file attached." });
      if (ctx.user.role === "student") {
        const enrolled = await db.select({ id: courseEnrollments.id }).from(courseEnrollments).where(and(eq(courseEnrollments.courseId, assignment[0].courseId), eq(courseEnrollments.studentId, ctx.user.id), eq(courseEnrollments.status, "active"))).limit(1);
        if (!enrolled[0]) throw new TRPCError({ code: "FORBIDDEN" });
      } else if (ctx.user.role === "faculty" && assignment[0].facultyId !== ctx.user.id && !(await facultyHasCourseAccess(ctx.user.id, assignment[0].courseId))) throw new TRPCError({ code: "FORBIDDEN" });
      return { url: await storageGetSignedUrl(assignment[0].questionFileKey) };
    }),
  }),
  submissions: router({
    mine: studentProcedure.query(({ ctx }) => listStudentSubmissions(ctx.user.id)),
    grades: studentProcedure.query(async ({ ctx }) => (await listStudentSubmissions(ctx.user.id)).filter(row => row.status === "graded" || row.status === "returned")),
    timeline: studentProcedure.input(z.object({ assignmentId: z.number().int().positive() })).query(async ({ ctx, input }) => {
      const row = await getStudentAssignmentDetails(ctx.user.id, input.assignmentId);
      if (!row) throw new TRPCError({ code: "NOT_FOUND", message: "Assignment not found in your enrolled courses." });
      return getSubmissionTimeline(ctx.user.id, input.assignmentId);
    }),
    byAssignment: facultyProcedure.input(z.object({ assignmentId: z.number().int().positive() })).query(({ ctx, input }) => getFacultySubmissionDetail(ctx.user.id, input.assignmentId)),
    facultyList: facultyProcedure.input(z.object({ assignmentId: z.number().int().positive().optional() }).optional()).query(({ ctx, input }) => listFacultySubmissions(ctx.user.id, input?.assignmentId)),
    submit: studentProcedure.input(z.object({ assignmentId: z.number().int().positive(), file: fileSchema, submissionText: z.string().max(10000).optional() })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const assignment = await db.select().from(assignments).where(eq(assignments.id, input.assignmentId)).limit(1);
      if (!assignment[0] || assignment[0].status !== "published") throw new TRPCError({ code: "NOT_FOUND", message: "Assignment is not available." });
      const enrolled = await db.select({ id: courseEnrollments.id }).from(courseEnrollments).where(and(eq(courseEnrollments.courseId, assignment[0].courseId), eq(courseEnrollments.studentId, ctx.user.id), eq(courseEnrollments.status, "active"))).limit(1);
      if (!enrolled[0]) throw new TRPCError({ code: "FORBIDDEN" });
      const extension = input.file.fileName.split(".").pop()?.toLowerCase() ?? "";
      const allowedExtensions = assignment[0].allowedFileTypes.split(",").map(value => value.trim().toLowerCase().replace(/^\./, ""));
      if (!allowedExtensions.includes(extension) || input.file.fileSize > assignment[0].fileSizeLimit) throw new TRPCError({ code: "BAD_REQUEST", message: `Upload one of: ${allowedExtensions.join(", ")} within ${Math.round(assignment[0].fileSizeLimit / 1_000_000)} MB.` });
      const existing = await db.select({ id: submissions.id }).from(submissions).where(and(eq(submissions.assignmentId, input.assignmentId), eq(submissions.studentId, ctx.user.id))).limit(1);
      if (existing[0]) throw new TRPCError({ code: "CONFLICT", message: "You already submitted this assignment." });
      const uploaded = await storagePut(`submissions/${ctx.user.id}/${input.file.fileName}`, Buffer.from(input.file.fileBase64, "base64"), input.file.mimeType);
      const status = Date.now() > assignment[0].dueAt ? "late" : "submitted";
      const result = await db.insert(submissions).values({ assignmentId: input.assignmentId, studentId: ctx.user.id, fileKey: uploaded.key, fileName: input.file.fileName, fileSize: input.file.fileSize, mimeType: input.file.mimeType, submissionText: input.submissionText, submittedAt: Date.now(), status });
      await createNotification(assignment[0].facultyId, "submission", "New submission received", `${ctx.user.name ?? "A student"} submitted ${assignment[0].title}.`, `/assignments/${input.assignmentId}`);
      await createNotification(ctx.user.id, "submission_success", "Submission successful", `Your submission for ${assignment[0].title} was received${status === "late" ? " late" : ""}.`, `/submissions`);
      return { id: Number(result[0].insertId), status };
    }),
    fileUrl: protectedProcedure.input(z.object({ id: z.number().int().positive() })).query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const row = await db.select({ submission: submissions, assignment: assignments }).from(submissions).innerJoin(assignments, eq(submissions.assignmentId, assignments.id)).where(eq(submissions.id, input.id)).limit(1);
      if (!row[0]) throw new TRPCError({ code: "NOT_FOUND" });
      if (ctx.user.role === "student" && row[0].submission.studentId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
      if (ctx.user.role === "faculty" && row[0].assignment.facultyId !== ctx.user.id && !(await facultyHasCourseAccess(ctx.user.id, row[0].assignment.courseId))) throw new TRPCError({ code: "FORBIDDEN" });
      return { url: await storageGetSignedUrl(row[0].submission.fileKey) };
    }),
    evaluate: facultyProcedure.input(z.object({ id: z.number().int().positive(), marks: z.number().int().min(0), feedback: z.string().max(5000).optional() })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const row = await db.select({ submission: submissions, assignment: assignments }).from(submissions).innerJoin(assignments, eq(submissions.assignmentId, assignments.id)).where(eq(submissions.id, input.id)).limit(1);
      if (!row[0] || (ctx.user.role === "faculty" && row[0].assignment.facultyId !== ctx.user.id && !(await facultyHasCourseAccess(ctx.user.id, row[0].assignment.courseId)))) throw new TRPCError({ code: "FORBIDDEN" });
      if (input.marks > row[0].assignment.maxMarks) throw new TRPCError({ code: "BAD_REQUEST", message: "Marks cannot exceed the maximum." });
      await db.update(submissions).set({ marks: input.marks, feedback: input.feedback ?? null, gradedById: ctx.user.id, gradedAt: Date.now() }).where(eq(submissions.id, input.id));
      if (input.feedback) await createNotification(row[0].submission.studentId, "feedback", "Feedback received", `Feedback is available for ${row[0].assignment.title}.`, `/grades`);
      return { success: true };
    }),
    grade: facultyProcedure.input(z.object({ id: z.number().int().positive(), marks: z.number().int().min(0), feedback: z.string().max(5000).optional() })).mutation(async ({ ctx, input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const row = await db.select({ submission: submissions, assignment: assignments }).from(submissions).innerJoin(assignments, eq(submissions.assignmentId, assignments.id)).where(eq(submissions.id, input.id)).limit(1);
      if (!row[0] || (ctx.user.role === "faculty" && row[0].assignment.facultyId !== ctx.user.id && !(await facultyHasCourseAccess(ctx.user.id, row[0].assignment.courseId)))) throw new TRPCError({ code: "FORBIDDEN" });
      if (input.marks > row[0].assignment.maxMarks) throw new TRPCError({ code: "BAD_REQUEST", message: "Marks cannot exceed the maximum." });
      await db.update(submissions).set({ marks: input.marks, feedback: input.feedback ?? null, status: "graded", gradedById: ctx.user.id, gradedAt: Date.now() }).where(eq(submissions.id, input.id));
      await createNotification(row[0].submission.studentId, "grade", "Assignment graded", `Your ${row[0].assignment.title} submission has been graded.`, `/assignments/${row[0].assignment.id}`);
      return { success: true };
    }),
    publishGrade: facultyProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const row = await db.select({ submission: submissions, assignment: assignments }).from(submissions).innerJoin(assignments, eq(submissions.assignmentId, assignments.id)).where(eq(submissions.id, input.id)).limit(1);
      if (!row[0] || (ctx.user.role === "faculty" && row[0].assignment.facultyId !== ctx.user.id && !(await facultyHasCourseAccess(ctx.user.id, row[0].assignment.courseId)))) throw new TRPCError({ code: "FORBIDDEN" });
      if (row[0].submission.marks === null) throw new TRPCError({ code: "BAD_REQUEST", message: "Save marks before publishing." });
      await db.update(submissions).set({ status: "graded" }).where(eq(submissions.id, input.id));
      await createNotification(row[0].submission.studentId, "grade", "Assignment graded", `Your ${row[0].assignment.title} marks are now published.`, `/grades`);
      return { success: true };
    }),
  }),
  notifications: router({
    list: protectedProcedure.query(async ({ ctx }) => { await ensureDeadlineNotifications(ctx.user.id, ctx.user.role); return getNotificationCenter(ctx.user.id); }),
    markRead: protectedProcedure.input(z.object({ id: z.number().int().positive().optional() })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.update(notifications).set({ readAt: Date.now() }).where(input.id ? and(eq(notifications.id, input.id), eq(notifications.userId, ctx.user.id)) : eq(notifications.userId, ctx.user.id));
      return { success: true };
    }),
    markAllRead: protectedProcedure.mutation(async ({ ctx }) => { const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" }); await db.update(notifications).set({ readAt: Date.now() }).where(eq(notifications.userId, ctx.user.id)); return { success: true }; }),
  }),
  announcements: router({
    list: protectedProcedure.query(({ ctx }) => listAnnouncements(ctx.user.role)),
    create: adminOnlyProcedure.input(z.object({ title: z.string().min(3).max(180), body: z.string().min(3).max(5000), audience: z.enum(["all", "student", "faculty", "admin"]).default("all") })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const result = await db.insert(announcements).values({ authorId: ctx.user.id, title: input.title, body: input.body, audience: input.audience, status: "published", publishedAt: Date.now() });
      return { id: Number(result[0].insertId) };
    }),
  }),
  admin: router({
    dashboard: adminOnlyProcedure.query(() => getAdminDashboard()),
    users: adminOnlyProcedure.input(z.object({ role: z.string().optional(), search: z.string().optional() }).optional()).query(({ input }) => listAdminUsers(input)),
    departments: adminOnlyProcedure.input(z.object({ search: z.string().optional() }).optional()).query(({ input }) => listAdminDepartments(input)),
    courses: adminOnlyProcedure.input(z.object({ search: z.string().optional(), departmentId: z.number().int().positive().optional() }).optional()).query(({ input }) => listAdminCourses(input)),
    assignments: adminOnlyProcedure.input(z.object({ search: z.string().optional(), courseId: z.number().int().positive().optional(), facultyId: z.number().int().positive().optional(), status: z.enum(["all", "draft", "published", "closed"]).optional() }).optional()).query(({ input }) => listAdminAssignments(input)),
    courseMembers: adminOnlyProcedure.input(z.object({ courseId: z.number().int().positive() })).query(({ input }) => listCourseMembers(input.courseId)),
    createUser: adminOnlyProcedure.input(z.object({ name: z.string().min(2).max(120), email: z.string().email(), role: z.enum(["student", "faculty", "admin"]), studentId: z.string().max(40).optional(), employeeId: z.string().max(40).optional(), departmentId: z.number().int().positive().optional(), yearOfStudy: z.number().int().min(1).max(8).optional() })).mutation(async ({ input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const result = await db.insert(users).values({ ...input, openId: `admin-created-${Date.now()}-${Math.random().toString(36).slice(2)}`, loginMethod: "pending-manus-login" });
      return { id: Number(result[0].insertId) };
    }),
    updateUser: adminOnlyProcedure.input(z.object({ id: z.number().int().positive(), name: z.string().min(2).max(120), role: z.enum(["student", "faculty", "admin"]), studentId: z.string().max(40).nullable().optional(), employeeId: z.string().max(40).nullable().optional(), departmentId: z.number().int().positive().nullable().optional(), yearOfStudy: z.number().int().min(1).max(8).nullable().optional() })).mutation(async ({ input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.update(users).set({ name: input.name, role: input.role, studentId: input.studentId ?? null, employeeId: input.employeeId ?? null, departmentId: input.departmentId ?? null, yearOfStudy: input.yearOfStudy ?? null }).where(eq(users.id, input.id));
      return { success: true };
    }),
    createDepartment: adminOnlyProcedure.input(z.object({ code: z.string().min(2).max(16), name: z.string().min(2).max(120), description: z.string().max(600).optional() })).mutation(async ({ input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const result = await db.insert(departments).values(input); return { id: Number(result[0].insertId) };
    }),
    updateDepartment: adminOnlyProcedure.input(z.object({ id: z.number().int().positive(), code: z.string().min(2).max(16), name: z.string().min(2).max(120), description: z.string().max(600).optional() })).mutation(async ({ input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.update(departments).set({ code: input.code, name: input.name, description: input.description ?? null }).where(eq(departments.id, input.id)); return { success: true };
    }),
    createCourse: adminOnlyProcedure.input(z.object({ code: z.string().min(2).max(20), title: z.string().min(3).max(160), description: z.string().max(1200).optional(), credits: z.number().int().min(1).max(8), departmentId: z.number().int().positive().optional(), semester: z.string().max(40).optional(), academicYear: z.string().max(20).optional() })).mutation(async ({ ctx, input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const result = await db.insert(courses).values({ ...input, createdById: ctx.user.id }); return { id: Number(result[0].insertId) };
    }),
    updateCourse: adminOnlyProcedure.input(z.object({ id: z.number().int().positive(), code: z.string().min(2).max(20), title: z.string().min(3).max(160), description: z.string().max(1200).optional(), credits: z.number().int().min(1).max(8), departmentId: z.number().int().positive().nullable().optional(), semester: z.string().max(40).optional(), academicYear: z.string().max(20).optional(), status: z.enum(["active", "archived"]) })).mutation(async ({ input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.update(courses).set({ code: input.code, title: input.title, description: input.description ?? null, credits: input.credits, departmentId: input.departmentId ?? null, semester: input.semester ?? null, academicYear: input.academicYear ?? null, status: input.status }).where(eq(courses.id, input.id)); return { success: true };
    }),
    enrollStudent: adminOnlyProcedure.input(z.object({ courseId: z.number().int().positive(), studentId: z.number().int().positive() })).mutation(async ({ input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const student = await db.select({ id: users.id, role: users.role }).from(users).where(eq(users.id, input.studentId)).limit(1); if (!student[0] || student[0].role !== "student") throw new TRPCError({ code: "BAD_REQUEST", message: "Only student accounts can be enrolled." });
      await db.insert(courseEnrollments).values(input); await createNotification(input.studentId, "enrollment", "Course enrollment updated", "You have been enrolled in a new course.", `/courses/${input.courseId}`); return { success: true };
    }),
    removeEnrollment: adminOnlyProcedure.input(z.object({ enrollmentId: z.number().int().positive() })).mutation(async ({ input }) => { const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" }); await db.delete(courseEnrollments).where(eq(courseEnrollments.id, input.enrollmentId)); return { success: true }; }),
    assignFaculty: adminOnlyProcedure.input(z.object({ courseId: z.number().int().positive(), facultyId: z.number().int().positive() })).mutation(async ({ input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" }); const faculty = await db.select({ id: users.id, role: users.role }).from(users).where(eq(users.id, input.facultyId)).limit(1); if (!faculty[0] || faculty[0].role !== "faculty") throw new TRPCError({ code: "BAD_REQUEST", message: "Only faculty accounts can be assigned." }); await db.insert(facultyCourseAssignments).values(input); return { success: true };
    }),
    removeFaculty: adminOnlyProcedure.input(z.object({ assignmentId: z.number().int().positive() })).mutation(async ({ input }) => { const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" }); await db.delete(facultyCourseAssignments).where(eq(facultyCourseAssignments.id, input.assignmentId)); return { success: true }; }),
  }),
});

export type AppRouter = typeof appRouter;
