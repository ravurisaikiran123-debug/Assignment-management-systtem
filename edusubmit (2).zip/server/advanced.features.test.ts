import { afterEach, describe, expect, it } from "vitest";
import { and, eq, inArray } from "drizzle-orm";
import { appRouter } from "./routers";
import { getDb } from "./db";
import { assignments, courseEnrollments, courses, notifications, submissions, users } from "../drizzle/schema";
import type { TrpcContext } from "./_core/context";

const userIds: number[] = []; const courseIds: number[] = []; const assignmentIds: number[] = [];
const contextFor = (user: any): TrpcContext => ({ user, req: { protocol: "https", headers: {} } as TrpcContext["req"], res: { clearCookie: () => undefined } as TrpcContext["res"] });

afterEach(async () => { const db = await getDb(); if (!db) return; if (assignmentIds.length) await db.delete(submissions).where(inArray(submissions.assignmentId, assignmentIds)); if (courseIds.length) { await db.delete(assignments).where(inArray(assignments.id, assignmentIds.splice(0))); await db.delete(courseEnrollments).where(inArray(courseEnrollments.courseId, courseIds)); await db.delete(courses).where(inArray(courses.id, courseIds.splice(0))); } if (userIds.length) { await db.delete(notifications).where(inArray(notifications.userId, userIds)); await db.delete(users).where(inArray(users.id, userIds.splice(0))); } });

describe("advanced portal features", () => {
  it("scopes the calendar to an enrolled student and creates one deadline reminder", async () => {
    const db = await getDb(); if (!db) throw new Error("DATABASE_URL is required"); const suffix = Date.now().toString();
    const studentInsert = await db.insert(users).values({ openId: `advanced-student-${suffix}`, name: "Advanced Student", email: `advanced-${suffix}@test.local`, role: "student" });
    const otherStudentInsert = await db.insert(users).values({ openId: `advanced-other-${suffix}`, name: "Other Student", email: `other-${suffix}@test.local`, role: "student" });
    const studentId = Number(studentInsert[0].insertId); const otherId = Number(otherStudentInsert[0].insertId); userIds.push(studentId, otherId);
    const courseInsert = await db.insert(courses).values({ code: `AD${suffix.slice(-10)}`, title: "Advanced Features", credits: 4, status: "active", createdById: studentId }); const courseId = Number(courseInsert[0].insertId); courseIds.push(courseId);
    await db.insert(courseEnrollments).values({ courseId, studentId, status: "active" });
    const dueAt = Date.now() + 24 * 60 * 60 * 1000; const assignmentInsert = await db.insert(assignments).values({ courseId, facultyId: studentId, title: "Calendar Assignment", dueAt, maxMarks: 100, status: "published" }); const assignmentId = Number(assignmentInsert[0].insertId); assignmentIds.push(assignmentId);
    const student = { id: studentId, openId: `advanced-student-${suffix}`, name: "Advanced Student", email: `advanced-${suffix}@test.local`, role: "student", studentId: null, employeeId: null, departmentId: null, yearOfStudy: null, avatarUrl: null, bio: null, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() };
    const caller = appRouter.createCaller(contextFor(student)); const month = new Date(dueAt).toISOString().slice(0, 7); const calendar = await caller.dashboard.calendar({ month }); expect(calendar.some(row => row.id === assignmentId)).toBe(true); await caller.notifications.list(); await caller.notifications.list(); const reminders = await db.select({ id: notifications.id }).from(notifications).where(and(eq(notifications.userId, studentId), eq(notifications.type, "deadline"), eq(notifications.relatedUrl, `/assignments/${assignmentId}`))); expect(reminders).toHaveLength(1); await expect(appRouter.createCaller(contextFor({ ...student, id: otherId, openId: `advanced-other-${suffix}` })).dashboard.calendar({ month })).resolves.toEqual([]);
  }, 15_000);
});
