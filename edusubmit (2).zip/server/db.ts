import { and, asc, desc, eq, gte, inArray, like, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  announcements,
  assignments,
  courseEnrollments,
  courses,
  departments,
  facultyCourseAssignments,
  notifications,
  profiles,
  submissions,
  InsertUser,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod", "studentId", "employeeId", "avatarUrl", "bio"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.departmentId !== undefined) { values.departmentId = user.departmentId; updateSet.departmentId = user.departmentId; }
  if (user.yearOfStudy !== undefined) { values.yearOfStudy = user.yearOfStudy; updateSet.yearOfStudy = user.yearOfStudy; }
  if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
  if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
  else if (user.openId === ENV.ownerOpenId) { values.role = "admin"; updateSet.role = "admin"; }
  values.lastSignedIn ??= new Date();
  updateSet.lastSignedIn ??= new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  const synced = await db.select({
    id: users.id,
    name: users.name,
    email: users.email,
    role: users.role,
    studentId: users.studentId,
    employeeId: users.employeeId,
    departmentId: users.departmentId,
    avatarUrl: users.avatarUrl,
  }).from(users).where(eq(users.openId, user.openId)).limit(1);
  const current = synced[0];
  if (current) {
    await db.insert(profiles).values({
      id: current.id,
      fullName: current.name,
      email: current.email,
      role: current.role,
      studentId: current.studentId,
      employeeId: current.employeeId,
      departmentId: current.departmentId,
      profileImage: current.avatarUrl,
    }).onDuplicateKeyUpdate({
      set: {
        fullName: current.name,
        email: current.email,
        role: current.role,
        studentId: current.studentId,
        employeeId: current.employeeId,
        departmentId: current.departmentId,
        profileImage: current.avatarUrl,
      },
    });
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result[0];
}

export async function getProfileById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(profiles).where(eq(profiles.id, id)).limit(1);
  return result[0];
}

export async function facultyHasCourseAccess(facultyId: number, courseId: number) {
  const db = await getDb();
  if (!db) return false;
  const result = await db.select({ id: facultyCourseAssignments.id }).from(facultyCourseAssignments).where(and(eq(facultyCourseAssignments.facultyId, facultyId), eq(facultyCourseAssignments.courseId, courseId))).limit(1);
  return Boolean(result[0]);
}

export async function listCoursesForUser(userId: number, role: string) {
  const db = await getDb();
  if (!db) return [];
  if (role === "student") {
    return db.select({
      id: courses.id, code: courses.code, title: courses.title, description: courses.description,
      credits: courses.credits, semester: courses.semester, academicYear: courses.academicYear,
      status: courses.status, enrolledAt: courseEnrollments.enrolledAt,
    }).from(courseEnrollments).innerJoin(courses, eq(courseEnrollments.courseId, courses.id))
      .where(and(eq(courseEnrollments.studentId, userId), eq(courseEnrollments.status, "active")))
      .orderBy(asc(courses.code));
  }
  if (role === "faculty") {
    return db.select({
      id: courses.id, code: courses.code, title: courses.title, description: courses.description,
      credits: courses.credits, semester: courses.semester, academicYear: courses.academicYear,
      status: courses.status, assignedAt: facultyCourseAssignments.assignedAt,
    }).from(facultyCourseAssignments).innerJoin(courses, eq(facultyCourseAssignments.courseId, courses.id))
      .where(eq(facultyCourseAssignments.facultyId, userId)).orderBy(asc(courses.code));
  }
  return db.select().from(courses).orderBy(asc(courses.code));
}

export async function listAssignmentsForUser(userId: number, role: string, search?: string) {
  const db = await getDb();
  if (!db) return [];
  const searchFilter = search ? or(like(assignments.title, `%${search}%`), like(courses.code, `%${search}%`), like(courses.title, `%${search}%`)) : undefined;
  if (role === "student") {
    return db.select({
      id: assignments.id, title: assignments.title, description: assignments.description, instructions: assignments.instructions,
      dueAt: assignments.dueAt, maxMarks: assignments.maxMarks, status: assignments.status, questionFileKey: assignments.questionFileKey,
      questionFileName: assignments.questionFileName, courseId: courses.id, courseCode: courses.code, courseTitle: courses.title,
      submissionId: submissions.id, submissionStatus: submissions.status, submittedAt: submissions.submittedAt, marks: submissions.marks, feedback: submissions.feedback,
    }).from(courseEnrollments).innerJoin(courses, eq(courseEnrollments.courseId, courses.id)).innerJoin(assignments, eq(assignments.courseId, courses.id))
      .leftJoin(submissions, and(eq(submissions.assignmentId, assignments.id), eq(submissions.studentId, userId)))
      .where(and(eq(courseEnrollments.studentId, userId), eq(courseEnrollments.status, "active"), eq(assignments.status, "published"), searchFilter))
      .orderBy(asc(assignments.dueAt));
  }
  if (role === "faculty") {
    return db.select({
      id: assignments.id, title: assignments.title, description: assignments.description, instructions: assignments.instructions,
      dueAt: assignments.dueAt, maxMarks: assignments.maxMarks, status: assignments.status, questionFileKey: assignments.questionFileKey,
      questionFileName: assignments.questionFileName, courseId: courses.id, courseCode: courses.code, courseTitle: courses.title,
      submissionCount: sql<number>`count(${submissions.id})`, gradedCount: sql<number>`sum(case when ${submissions.status} in ('graded','returned') then 1 else 0 end)`,
    }).from(assignments).innerJoin(courses, eq(assignments.courseId, courses.id)).leftJoin(submissions, eq(submissions.assignmentId, assignments.id))
      .where(and(eq(assignments.facultyId, userId), searchFilter)).groupBy(assignments.id, courses.id).orderBy(desc(assignments.createdAt));
  }
  return db.select({
    id: assignments.id, title: assignments.title, description: assignments.description, dueAt: assignments.dueAt,
    maxMarks: assignments.maxMarks, status: assignments.status, courseCode: courses.code, courseTitle: courses.title,
    submissionCount: sql<number>`count(${submissions.id})`,
  }).from(assignments).innerJoin(courses, eq(assignments.courseId, courses.id)).leftJoin(submissions, eq(submissions.assignmentId, assignments.id))
    .where(searchFilter).groupBy(assignments.id, courses.id).orderBy(desc(assignments.createdAt));
}

export async function listNotifications(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(notifications).where(eq(notifications.userId, userId)).orderBy(desc(notifications.createdAt)).limit(20);
}

export async function listAnnouncements(role: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(announcements).where(and(eq(announcements.status, "published"), or(eq(announcements.audience, "all"), eq(announcements.audience, role)))).orderBy(desc(announcements.publishedAt), desc(announcements.createdAt)).limit(10);
}

export async function createNotification(userId: number, type: string, title: string, body: string, relatedUrl?: string) {
  const db = await getDb();
  if (!db) return;
  await db.insert(notifications).values({ userId, type, title, body, relatedUrl, createdAt: Date.now() });
}

export async function notifyCourseStudents(courseId: number, type: string, title: string, body: string, relatedUrl?: string) {
  const db = await getDb();
  if (!db) return;
  const enrolled = await db.select({ studentId: courseEnrollments.studentId }).from(courseEnrollments)
    .where(and(eq(courseEnrollments.courseId, courseId), eq(courseEnrollments.status, "active")));
  if (enrolled.length) await db.insert(notifications).values(enrolled.map(({ studentId }) => ({ userId: studentId, type, title, body, relatedUrl, createdAt: Date.now() })));
}

export async function getDashboardStats(userId: number, role: string) {
  const db = await getDb();
  if (!db) return { courses: 0, assignments: 0, submissions: 0, pending: 0, average: 0, unread: 0 };
  const unreadRows = await db.select({ count: sql<number>`count(*)` }).from(notifications).where(and(eq(notifications.userId, userId), sql`${notifications.readAt} is null`));
  if (role === "student") {
    const courseRows = await db.select({ count: sql<number>`count(*)` }).from(courseEnrollments).where(and(eq(courseEnrollments.studentId, userId), eq(courseEnrollments.status, "active")));
    const assignmentRows = await db.select({ count: sql<number>`count(*)` }).from(courseEnrollments).innerJoin(assignments, eq(assignments.courseId, courseEnrollments.courseId)).where(and(eq(courseEnrollments.studentId, userId), eq(courseEnrollments.status, "active"), eq(assignments.status, "published")));
    const submissionRows = await db.select({ count: sql<number>`count(*)` }).from(submissions).where(eq(submissions.studentId, userId));
    const pendingRows = await db.select({ count: sql<number>`count(*)` }).from(courseEnrollments).innerJoin(assignments, eq(assignments.courseId, courseEnrollments.courseId)).leftJoin(submissions, and(eq(submissions.assignmentId, assignments.id), eq(submissions.studentId, userId))).where(and(eq(courseEnrollments.studentId, userId), eq(assignments.status, "published"), sql`${submissions.id} is null`));
    const averageRows = await db.select({ average: sql<number>`coalesce(avg(${submissions.marks} / nullif(${assignments.maxMarks}, 0) * 100), 0)` }).from(submissions).innerJoin(assignments, eq(submissions.assignmentId, assignments.id)).where(eq(submissions.studentId, userId));
    return { courses: Number(courseRows[0]?.count ?? 0), assignments: Number(assignmentRows[0]?.count ?? 0), submissions: Number(submissionRows[0]?.count ?? 0), pending: Number(pendingRows[0]?.count ?? 0), average: Math.round(Number(averageRows[0]?.average ?? 0)), unread: Number(unreadRows[0]?.count ?? 0) };
  }
  if (role === "faculty") {
    const courseRows = await db.select({ count: sql<number>`count(*)` }).from(facultyCourseAssignments).where(eq(facultyCourseAssignments.facultyId, userId));
    const assignmentRows = await db.select({ count: sql<number>`count(*)` }).from(assignments).where(eq(assignments.facultyId, userId));
    const submissionRows = await db.select({ count: sql<number>`count(*)` }).from(assignments).innerJoin(submissions, eq(submissions.assignmentId, assignments.id)).where(eq(assignments.facultyId, userId));
    const pendingRows = await db.select({ count: sql<number>`count(*)` }).from(assignments).innerJoin(submissions, eq(submissions.assignmentId, assignments.id)).where(and(eq(assignments.facultyId, userId), sql`${submissions.status} in ('submitted','late')`));
    return { courses: Number(courseRows[0]?.count ?? 0), assignments: Number(assignmentRows[0]?.count ?? 0), submissions: Number(submissionRows[0]?.count ?? 0), pending: Number(pendingRows[0]?.count ?? 0), average: 0, unread: Number(unreadRows[0]?.count ?? 0) };
  }
  const [studentRows, facultyRows, courseRows, assignmentRows, submissionRows] = await Promise.all([
    db.select({ count: sql<number>`count(*)` }).from(users).where(eq(users.role, "student")),
    db.select({ count: sql<number>`count(*)` }).from(users).where(eq(users.role, "faculty")),
    db.select({ count: sql<number>`count(*)` }).from(courses).where(eq(courses.status, "active")),
    db.select({ count: sql<number>`count(*)` }).from(assignments),
    db.select({ count: sql<number>`count(*)` }).from(submissions),
  ]);
  return { courses: Number(courseRows[0]?.count ?? 0), assignments: Number(assignmentRows[0]?.count ?? 0), submissions: Number(submissionRows[0]?.count ?? 0), pending: Number(studentRows[0]?.count ?? 0), average: Number(facultyRows[0]?.count ?? 0), unread: Number(unreadRows[0]?.count ?? 0) };
}

export async function getFacultySubmissionDetail(facultyId: number, assignmentId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({ id: submissions.id, assignmentId: submissions.assignmentId, studentId: submissions.studentId, fileKey: submissions.fileKey, fileName: submissions.fileName, fileSize: submissions.fileSize, submittedAt: submissions.submittedAt, status: submissions.status, marks: submissions.marks, feedback: submissions.feedback, studentName: users.name, studentEmail: users.email, maxMarks: assignments.maxMarks, assignmentTitle: assignments.title })
    .from(submissions).innerJoin(assignments, eq(submissions.assignmentId, assignments.id)).innerJoin(users, eq(submissions.studentId, users.id))
    .where(and(eq(assignments.facultyId, facultyId), eq(assignments.id, assignmentId))).orderBy(desc(submissions.submittedAt));
}

export { announcements, assignments, courseEnrollments, courses, departments, facultyCourseAssignments, notifications, profiles, submissions, users };
