import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import { sdk } from "./_core/sdk";
import { COOKIE_NAME } from "../shared/const";
import type { TrpcContext } from "./_core/context";

describe("Manus session persistence", () => {
  it("verifies the same signed session across refresh and reopen-like reads", async () => {
    const token = await sdk.createSessionToken("session-persistence-user", { name: "Persistent User" });
    const firstRead = await sdk.verifySession(token);
    const secondRead = await sdk.verifySession(token);
    expect(firstRead).toEqual(secondRead);
    expect(firstRead?.openId).toBe("session-persistence-user");
  });

  it("logout clears the session cookie without mutating the database user record", async () => {
    const cleared: string[] = [];
    const ctx: TrpcContext = {
      user: {
        id: 9001,
        openId: "logout-persistence-user",
        email: "persist@example.com",
        name: "Persisted User",
        loginMethod: "manus",
        role: "student",
        studentId: "STU-PERSIST",
        employeeId: null,
        departmentId: null,
        yearOfStudy: 2,
        avatarUrl: null,
        bio: null,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      },
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: { clearCookie: (name: string) => cleared.push(name) } as TrpcContext["res"],
    };
    await appRouter.createCaller(ctx).auth.logout();
    expect(cleared).toEqual([COOKIE_NAME]);
    expect(ctx.user?.openId).toBe("logout-persistence-user");
  });
});
