import { and, asc, desc, eq, like, or, sql } from "drizzle-orm";
import { assignments, courses, facultyCourseAssignments, submissions, users } from "../drizzle/schema";
import { getDb } from "./db";

export async function getFacultyDashboard(facultyId: number) {
  const db = await getDb();
  if (!db) return { assignedCourses: 0, totalAssignments: 0, activeAssignments: 0, totalSubmissions: 0, pendingEvaluations: 0, upcomingDeadlines: [], recentActivity: [] };
  const now = Date.now();
  const [coursesCount, assignmentsCount, activeCount, submissionsCount, pendingCount, upcomingDeadlines, recentActivity] = await Promise.all([
    db.select({ count: sql<number>`count(*)` }).from(facultyCourseAssignments).where(eq(facultyCourseAssignments.facultyId, facultyId)),
    db.select({ count: sql<number>`count(*)` }).from(assignments).where(eq(assignments.facultyId, facultyId)),
    db.select({ count: sql<number>`count(*)` }).from(assignments).where(and(eq(assignments.facultyId, facultyId), eq(assignments.status, "published"))),
    db.select({ count: sql<number>`count(*)` }).from(assignments).innerJoin(submissions, eq(submissions.assignmentId, assignments.id)).where(eq(assignments.facultyId, facultyId)),
    db.select({ count: sql<number>`count(*)` }).from(assignments).innerJoin(submissions, eq(submissions.assignmentId, assignments.id)).where(and(eq(assignments.facultyId, facultyId), sql`${submissions.status} in ('submitted','late')`)),
    db.select({ id: assignments.id, title: assignments.title, dueAt: assignments.dueAt, maxMarks: assignments.maxMarks, status: assignments.status, courseCode: courses.code, courseTitle: courses.title, submissionCount: sql<number>`count(${submissions.id})` }).from(assignments).innerJoin(courses, eq(assignments.courseId, courses.id)).leftJoin(submissions, eq(submissions.assignmentId, assignments.id)).where(and(eq(assignments.facultyId, facultyId), sql`${assignments.dueAt} >= ${now}`)).groupBy(assignments.id, courses.id).orderBy(asc(assignments.dueAt)).limit(6),
    db.select({ id: submissions.id, assignmentTitle: assignments.title, studentName: users.name, studentId: users.studentId, submittedAt: submissions.submittedAt, status: submissions.status, marks: submissions.marks }).from(submissions).innerJoin(assignments, eq(submissions.assignmentId, assignments.id)).innerJoin(users, eq(submissions.studentId, users.id)).where(eq(assignments.facultyId, facultyId)).orderBy(desc(submissions.submittedAt)).limit(6),
  ]);
  return { assignedCourses: Number(coursesCount[0]?.count ?? 0), totalAssignments: Number(assignmentsCount[0]?.count ?? 0), activeAssignments: Number(activeCount[0]?.count ?? 0), totalSubmissions: Number(submissionsCount[0]?.count ?? 0), pendingEvaluations: Number(pendingCount[0]?.count ?? 0), upcomingDeadlines, recentActivity };
}

export async function listFacultyAssignments(facultyId: number, input: { search?: string; courseId?: number; status?: "all" | "draft" | "published" | "closed" }) {
  const db = await getDb();
  if (!db) return [];
  const searchFilter = input.search ? or(like(assignments.title, `%${input.search}%`), like(courses.code, `%${input.search}%`), like(courses.title, `%${input.search}%`)) : undefined;
  return db.select({ id: assignments.id, title: assignments.title, description: assignments.description, instructions: assignments.instructions, dueAt: assignments.dueAt, maxMarks: assignments.maxMarks, status: assignments.status, questionFileKey: assignments.questionFileKey, questionFileName: assignments.questionFileName, allowedFileTypes: assignments.allowedFileTypes, fileSizeLimit: assignments.fileSizeLimit, courseId: courses.id, courseCode: courses.code, courseTitle: courses.title, submissionCount: sql<number>`count(${submissions.id})`, pendingCount: sql<number>`sum(case when ${submissions.status} in ('submitted','late') then 1 else 0 end)` }).from(assignments).innerJoin(courses, eq(assignments.courseId, courses.id)).leftJoin(submissions, eq(submissions.assignmentId, assignments.id)).where(and(eq(assignments.facultyId, facultyId), searchFilter, input.courseId ? eq(courses.id, input.courseId) : undefined, input.status && input.status !== "all" ? eq(assignments.status, input.status) : undefined)).groupBy(assignments.id, courses.id).orderBy(desc(assignments.createdAt));
}

export async function listFacultySubmissions(facultyId: number, assignmentId?: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({ id: submissions.id, assignmentId: submissions.assignmentId, studentName: users.name, studentEmail: users.email, studentId: users.studentId, assignmentTitle: assignments.title, courseId: courses.id, courseCode: courses.code, courseTitle: courses.title, fileKey: submissions.fileKey, fileName: submissions.fileName, fileSize: submissions.fileSize, mimeType: submissions.mimeType, submissionText: submissions.submissionText, submittedAt: submissions.submittedAt, status: submissions.status, marks: submissions.marks, feedback: submissions.feedback, evaluatedBy: submissions.gradedById, evaluatedAt: submissions.gradedAt, maxMarks: assignments.maxMarks }).from(submissions).innerJoin(assignments, eq(submissions.assignmentId, assignments.id)).innerJoin(courses, eq(assignments.courseId, courses.id)).innerJoin(users, eq(submissions.studentId, users.id)).leftJoin(facultyCourseAssignments, eq(facultyCourseAssignments.courseId, assignments.courseId)).where(and(or(eq(assignments.facultyId, facultyId), eq(facultyCourseAssignments.facultyId, facultyId)), assignmentId ? eq(assignments.id, assignmentId) : undefined)).orderBy(desc(submissions.submittedAt));
}
