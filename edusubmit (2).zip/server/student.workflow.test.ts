import { afterEach, describe, expect, it } from "vitest";
import { and, eq, inArray } from "drizzle-orm";
import { appRouter } from "./routers";
import { getDb } from "./db";
import { assignments, courseEnrollments, courses, submissions, users } from "../drizzle/schema";
import type { TrpcContext } from "./_core/context";

const createdUserIds: number[] = [];
const createdCourseIds: number[] = [];
const createdAssignmentIds: number[] = [];
const createdSubmissionIds: number[] = [];

function ctx(user: any): TrpcContext {
  return { user, req: { protocol: "https", headers: {} } as TrpcContext["req"], res: { clearCookie: () => undefined } as TrpcContext["res"] };
}

afterEach(async () => {
  const db = await getDb();
  if (!db) return;
  if (createdSubmissionIds.length) await db.delete(submissions).where(inArray(submissions.id, createdSubmissionIds.splice(0)));
  if (createdAssignmentIds.length) await db.delete(assignments).where(inArray(assignments.id, createdAssignmentIds.splice(0)));
  if (createdCourseIds.length) await db.delete(courseEnrollments).where(inArray(courseEnrollments.courseId, createdCourseIds));
  if (createdCourseIds.length) await db.delete(courses).where(inArray(courses.id, createdCourseIds.splice(0)));
  if (createdUserIds.length) await db.delete(users).where(inArray(users.id, createdUserIds.splice(0)));
});

describe("student portal real database workflow", () => {
  it("shows enrolled assignment data and blocks another student's records and grading", async () => {
    const db = await getDb();
    if (!db) throw new Error("DATABASE_URL is required for the student workflow integration test");
    const suffix = Date.now().toString();
    const facultyInsert = await db.insert(users).values({ openId: `e2e-faculty-${suffix}`, name: "E2E Faculty", email: `faculty-${suffix}@test.local`, role: "faculty" });
    const studentInsert = await db.insert(users).values({ openId: `e2e-student-${suffix}`, name: "E2E Student", email: `student-${suffix}@test.local`, role: "student", studentId: `E2E-${suffix}` });
    const otherStudentInsert = await db.insert(users).values({ openId: `e2e-other-${suffix}`, name: "Other Student", email: `other-${suffix}@test.local`, role: "student", studentId: `OTHER-${suffix}` });
    const facultyId = Number(facultyInsert[0].insertId); const studentId = Number(studentInsert[0].insertId); const otherStudentId = Number(otherStudentInsert[0].insertId);
    createdUserIds.push(facultyId, studentId, otherStudentId);
    const courseInsert = await db.insert(courses).values({ code: `E2E${suffix.slice(-10)}`, title: "E2E Secure Course", credits: 4, status: "active", createdById: facultyId });
    const courseId = Number(courseInsert[0].insertId); createdCourseIds.push(courseId);
    await db.insert(courseEnrollments).values({ courseId, studentId, status: "active" });
    const assignmentInsert = await db.insert(assignments).values({ courseId, facultyId, title: "E2E Assignment", description: "Private assignment", instructions: "Submit your work", dueAt: Date.now() + 86_400_000, maxMarks: 100, status: "published" });
    const assignmentId = Number(assignmentInsert[0].insertId); createdAssignmentIds.push(assignmentId);
    const submissionInsert = await db.insert(submissions).values({ assignmentId, studentId: otherStudentId, fileKey: `e2e/${suffix}.pdf`, fileName: "other.pdf", fileSize: 10, mimeType: "application/pdf", submittedAt: Date.now(), status: "submitted" });
    const submissionId = Number(submissionInsert[0].insertId); createdSubmissionIds.push(submissionId);
    const studentUser = { id: studentId, openId: `e2e-student-${suffix}`, name: "E2E Student", email: `student-${suffix}@test.local`, loginMethod: "manus", role: "student", studentId: `E2E-${suffix}`, employeeId: null, departmentId: null, yearOfStudy: 1, avatarUrl: null, bio: null, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() };
    const caller = appRouter.createCaller(ctx(studentUser));
    const details = await caller.assignments.studentDetails({ id: assignmentId });
    expect(details.title).toBe("E2E Assignment");
    expect(details.submissionId).toBeNull();
    await expect(caller.submissions.fileUrl({ id: submissionId })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.submissions.grade({ id: submissionId, marks: 80 })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
