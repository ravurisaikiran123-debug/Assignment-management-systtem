import { and, eq, or } from "drizzle-orm";
import type { Express } from "express";
import { assignments, courseEnrollments, facultyCourseAssignments, submissions } from "../../drizzle/schema";
import { getDb } from "../db";
import { sdk } from "./sdk";
import { ENV } from "./env";

export function registerStorageProxy(app: Express) {
  app.get("/manus-storage/*", async (req, res) => {
    const key = (req.params as Record<string, string>)[0];
    if (!key) { res.status(400).send("Missing storage key"); return; }
    if (!ENV.forgeApiUrl || !ENV.forgeApiKey) { res.status(500).send("Storage proxy not configured"); return; }
    try {
      const user = await sdk.authenticateRequest(req);
      const db = await getDb();
      if (!db) { res.status(500).send("Database unavailable"); return; }
      const submission = await db.select({ studentId: submissions.studentId, facultyId: assignments.facultyId, courseId: assignments.courseId }).from(submissions).innerJoin(assignments, eq(submissions.assignmentId, assignments.id)).where(eq(submissions.fileKey, key)).limit(1);
      const question = await db.select({ facultyId: assignments.facultyId, courseId: assignments.courseId }).from(assignments).where(eq(assignments.questionFileKey, key)).limit(1);
      let allowed = user.role === "admin";
      if (submission[0]) {
        allowed ||= user.role === "student" && submission[0].studentId === user.id;
        allowed ||= user.role === "faculty" && (submission[0].facultyId === user.id || Boolean((await db.select({ id: facultyCourseAssignments.id }).from(facultyCourseAssignments).where(and(eq(facultyCourseAssignments.facultyId, user.id), eq(facultyCourseAssignments.courseId, submission[0].courseId))).limit(1))[0]));
      }
      if (question[0]) {
        allowed ||= user.role === "faculty" && (question[0].facultyId === user.id || Boolean((await db.select({ id: facultyCourseAssignments.id }).from(facultyCourseAssignments).where(and(eq(facultyCourseAssignments.facultyId, user.id), eq(facultyCourseAssignments.courseId, question[0].courseId))).limit(1))[0]));
        allowed ||= user.role === "student" && Boolean((await db.select({ id: courseEnrollments.id }).from(courseEnrollments).where(and(eq(courseEnrollments.studentId, user.id), eq(courseEnrollments.courseId, question[0].courseId), eq(courseEnrollments.status, "active"))).limit(1))[0]);
      }
      if (!allowed || (!submission[0] && !question[0])) { res.status(404).send("File not found"); return; }
      const forgeUrl = new URL("v1/storage/presign/get", ENV.forgeApiUrl.replace(/\/+$/, "") + "/");
      forgeUrl.searchParams.set("path", key);
      const forgeResp = await fetch(forgeUrl, { headers: { Authorization: `Bearer ${ENV.forgeApiKey}` } });
      if (!forgeResp.ok) { res.status(502).send("Storage backend error"); return; }
      const { url } = (await forgeResp.json()) as { url: string };
      if (!url) { res.status(502).send("Empty signed URL from backend"); return; }
      res.set("Cache-Control", "no-store"); res.redirect(307, url);
    } catch (err) {
      console.error("[StorageProxy] failed:", err);
      res.status(401).send("Unauthorized");
    }
  });
}
