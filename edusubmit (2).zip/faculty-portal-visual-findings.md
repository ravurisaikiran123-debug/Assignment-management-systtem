Visual verification findings for the faculty portal implementation:

The live authenticated preview rendered the /faculty and /assignments deep links inside the EduSubmit application shell without a 404. The current preview session is authenticated as an admin, so role-gated faculty dashboard content is intentionally not shown in the screenshot; the real faculty dashboard and management views are activated only when the authenticated user role is faculty. Backend integration tests cover the faculty-specific data and permission paths.
