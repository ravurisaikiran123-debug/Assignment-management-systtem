Visual verification findings for the student portal implementation:

- The existing authenticated dashboard shell renders consistently with the EduSubmit navy/parchment visual system.
- The assignment route rendered successfully with the existing admin-authenticated preview and showed the expected empty state when no assignments were available to that user.
- Direct navigation to /submissions and /grades initially rendered the 404 fallback because those paths were missing from client/src/App.tsx.
- Added explicit /submissions and /grades routes; final verification must re-capture those deep links.
- Student-specific navigation remains role-aware and is only added for users with the student role.
