import {
  bigint,
  index,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable(
  "users",
  {
    id: int("id").autoincrement().primaryKey(),
    openId: varchar("openId", { length: 64 }).notNull().unique(),
    name: text("name"),
    email: varchar("email", { length: 320 }),
    loginMethod: varchar("loginMethod", { length: 64 }),
    role: varchar("role", { length: 20 }).default("student").notNull(),
    studentId: varchar("studentId", { length: 40 }),
    employeeId: varchar("employeeId", { length: 40 }),
    departmentId: int("departmentId"),
    yearOfStudy: int("yearOfStudy"),
    avatarUrl: text("avatarUrl"),
    bio: text("bio"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
    lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
  },
  (table) => ({
    roleIdx: index("users_role_idx").on(table.role),
    departmentIdx: index("users_department_idx").on(table.departmentId),
  }),
);


/** Canonical application profile projection keyed to the Manus-authenticated user id. */
export const profiles = mysqlTable(
  "profiles",
  {
    id: int("id").primaryKey(),
    fullName: text("full_name"),
    email: varchar("email", { length: 320 }),
    role: varchar("role", { length: 20 }).default("student").notNull(),
    studentId: varchar("student_id", { length: 40 }),
    employeeId: varchar("employee_id", { length: 40 }),
    departmentId: int("department_id"),
    profileImage: text("profile_image"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    roleIdx: index("profiles_role_idx").on(table.role),
    departmentIdx: index("profiles_department_idx").on(table.departmentId),
    studentIdUnique: uniqueIndex("profiles_student_id_unique").on(table.studentId),
    employeeIdUnique: uniqueIndex("profiles_employee_id_unique").on(table.employeeId),
  }),
);

export const departments = mysqlTable(
  "departments",
  {
    id: int("id").autoincrement().primaryKey(),
    code: varchar("code", { length: 16 }).notNull(),
    name: varchar("name", { length: 120 }).notNull(),
    description: text("description"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({ codeUnique: uniqueIndex("departments_code_unique").on(table.code) }),
);

export const courses = mysqlTable(
  "courses",
  {
    id: int("id").autoincrement().primaryKey(),
    code: varchar("code", { length: 20 }).notNull(),
    title: varchar("title", { length: 160 }).notNull(),
    description: text("description"),
    credits: int("credits").default(4).notNull(),
    departmentId: int("departmentId"),
    semester: varchar("semester", { length: 40 }),
    academicYear: varchar("academicYear", { length: 20 }),
    status: mysqlEnum("status", ["active", "archived"]).default("active").notNull(),
    createdById: int("createdById").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    codeUnique: uniqueIndex("courses_code_unique").on(table.code),
    statusIdx: index("courses_status_idx").on(table.status),
    departmentIdx: index("courses_department_idx").on(table.departmentId),
  }),
);

export const courseEnrollments = mysqlTable(
  "course_enrollments",
  {
    id: int("id").autoincrement().primaryKey(),
    courseId: int("courseId").notNull(),
    studentId: int("studentId").notNull(),
    status: mysqlEnum("status", ["active", "dropped"]).default("active").notNull(),
    enrolledAt: timestamp("enrolledAt").defaultNow().notNull(),
  },
  (table) => ({
    courseStudentUnique: uniqueIndex("course_student_unique").on(table.courseId, table.studentId),
    studentIdx: index("enrollments_student_idx").on(table.studentId),
    courseIdx: index("enrollments_course_idx").on(table.courseId),
  }),
);

export const facultyCourseAssignments = mysqlTable(
  "faculty_course_assignments",
  {
    id: int("id").autoincrement().primaryKey(),
    courseId: int("courseId").notNull(),
    facultyId: int("facultyId").notNull(),
    assignedAt: timestamp("assignedAt").defaultNow().notNull(),
  },
  (table) => ({
    courseFacultyUnique: uniqueIndex("course_faculty_unique").on(table.courseId, table.facultyId),
    facultyIdx: index("faculty_assignments_faculty_idx").on(table.facultyId),
  }),
);

export const assignments = mysqlTable(
  "assignments",
  {
    id: int("id").autoincrement().primaryKey(),
    courseId: int("courseId").notNull(),
    facultyId: int("facultyId").notNull(),
    title: varchar("title", { length: 180 }).notNull(),
    description: text("description"),
    instructions: text("instructions"),
    dueAt: bigint("dueAt", { mode: "number" }).notNull(),
    maxMarks: int("maxMarks").default(100).notNull(),
    status: mysqlEnum("status", ["draft", "published", "closed"]).default("draft").notNull(),
    questionFileKey: text("questionFileKey"),
    questionFileName: varchar("questionFileName", { length: 255 }),
    allowedFileTypes: varchar("allowedFileTypes", { length: 500 }).default("pdf,doc,docx,txt,zip").notNull(),
    fileSizeLimit: int("fileSizeLimit").default(10_000_000).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    courseIdx: index("assignments_course_idx").on(table.courseId),
    facultyIdx: index("assignments_faculty_idx").on(table.facultyId),
    dueIdx: index("assignments_due_idx").on(table.dueAt),
    statusIdx: index("assignments_status_idx").on(table.status),
  }),
);

export const submissions = mysqlTable(
  "submissions",
  {
    id: int("id").autoincrement().primaryKey(),
    assignmentId: int("assignmentId").notNull(),
    studentId: int("studentId").notNull(),
    fileKey: text("fileKey").notNull(),
    fileName: varchar("fileName", { length: 255 }).notNull(),
    fileSize: int("fileSize").notNull(),
    mimeType: varchar("mimeType", { length: 120 }).notNull(),
    submissionText: text("submissionText"),
    submittedAt: bigint("submittedAt", { mode: "number" }).notNull(),
    status: mysqlEnum("status", ["submitted", "late", "graded", "returned"]).default("submitted").notNull(),
    marks: int("marks"),
    feedback: text("feedback"),
    gradedById: int("gradedById"),
    gradedAt: bigint("gradedAt", { mode: "number" }),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    assignmentStudentUnique: uniqueIndex("assignment_student_unique").on(table.assignmentId, table.studentId),
    studentIdx: index("submissions_student_idx").on(table.studentId),
    assignmentIdx: index("submissions_assignment_idx").on(table.assignmentId),
    statusIdx: index("submissions_status_idx").on(table.status),
  }),
);

export const notifications = mysqlTable(
  "notifications",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    type: varchar("type", { length: 40 }).notNull(),
    title: varchar("title", { length: 180 }).notNull(),
    body: text("body").notNull(),
    relatedUrl: varchar("relatedUrl", { length: 255 }),
    readAt: bigint("readAt", { mode: "number" }),
    createdAt: bigint("createdAt", { mode: "number" }).notNull(),
  },
  (table) => ({
    userIdx: index("notifications_user_idx").on(table.userId),
    unreadIdx: index("notifications_unread_idx").on(table.userId, table.readAt),
  }),
);

export const announcements = mysqlTable(
  "announcements",
  {
    id: int("id").autoincrement().primaryKey(),
    authorId: int("authorId").notNull(),
    title: varchar("title", { length: 180 }).notNull(),
    body: text("body").notNull(),
    audience: varchar("audience", { length: 30 }).default("all").notNull(),
    status: mysqlEnum("status", ["draft", "published"]).default("published").notNull(),
    publishedAt: bigint("publishedAt", { mode: "number" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    statusIdx: index("announcements_status_idx").on(table.status),
    publishedIdx: index("announcements_published_idx").on(table.publishedAt),
  }),
);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Course = typeof courses.$inferSelect;
export type Assignment = typeof assignments.$inferSelect;
export type Submission = typeof submissions.$inferSelect;
