CREATE TABLE `profiles` (
	`id` int NOT NULL,
	`full_name` text,
	`email` varchar(320),
	`role` varchar(20) NOT NULL DEFAULT 'student',
	`student_id` varchar(40),
	`employee_id` varchar(40),
	`department_id` int,
	`profile_image` text,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `profiles_student_id_unique` UNIQUE(`student_id`),
	CONSTRAINT `profiles_employee_id_unique` UNIQUE(`employee_id`)
);
--> statement-breakpoint
ALTER TABLE `submissions` ADD `submissionText` text;--> statement-breakpoint
ALTER TABLE `submissions` ADD `updatedAt` timestamp DEFAULT (now()) NOT NULL ON UPDATE CURRENT_TIMESTAMP;--> statement-breakpoint
ALTER TABLE `users` ADD `employeeId` varchar(40);--> statement-breakpoint
CREATE INDEX `profiles_role_idx` ON `profiles` (`role`);--> statement-breakpoint
CREATE INDEX `profiles_department_idx` ON `profiles` (`department_id`);