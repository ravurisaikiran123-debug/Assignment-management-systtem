CREATE TABLE `announcements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`authorId` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`body` text NOT NULL,
	`audience` varchar(30) NOT NULL DEFAULT 'all',
	`status` enum('draft','published') NOT NULL DEFAULT 'published',
	`publishedAt` bigint,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `announcements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `assignments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`courseId` int NOT NULL,
	`facultyId` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`description` text,
	`instructions` text,
	`dueAt` bigint NOT NULL,
	`maxMarks` int NOT NULL DEFAULT 100,
	`status` enum('draft','published','closed') NOT NULL DEFAULT 'draft',
	`questionFileKey` text,
	`questionFileName` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `assignments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `course_enrollments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`courseId` int NOT NULL,
	`studentId` int NOT NULL,
	`status` enum('active','dropped') NOT NULL DEFAULT 'active',
	`enrolledAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `course_enrollments_id` PRIMARY KEY(`id`),
	CONSTRAINT `course_student_unique` UNIQUE(`courseId`,`studentId`)
);
--> statement-breakpoint
CREATE TABLE `courses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(20) NOT NULL,
	`title` varchar(160) NOT NULL,
	`description` text,
	`credits` int NOT NULL DEFAULT 4,
	`departmentId` int,
	`semester` varchar(40),
	`academicYear` varchar(20),
	`status` enum('active','archived') NOT NULL DEFAULT 'active',
	`createdById` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `courses_id` PRIMARY KEY(`id`),
	CONSTRAINT `courses_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `departments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(16) NOT NULL,
	`name` varchar(120) NOT NULL,
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `departments_id` PRIMARY KEY(`id`),
	CONSTRAINT `departments_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `faculty_course_assignments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`courseId` int NOT NULL,
	`facultyId` int NOT NULL,
	`assignedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `faculty_course_assignments_id` PRIMARY KEY(`id`),
	CONSTRAINT `course_faculty_unique` UNIQUE(`courseId`,`facultyId`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`type` varchar(40) NOT NULL,
	`title` varchar(180) NOT NULL,
	`body` text NOT NULL,
	`relatedUrl` varchar(255),
	`readAt` bigint,
	`createdAt` bigint NOT NULL,
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `submissions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`assignmentId` int NOT NULL,
	`studentId` int NOT NULL,
	`fileKey` text NOT NULL,
	`fileName` varchar(255) NOT NULL,
	`fileSize` int NOT NULL,
	`mimeType` varchar(120) NOT NULL,
	`submittedAt` bigint NOT NULL,
	`status` enum('submitted','late','graded','returned') NOT NULL DEFAULT 'submitted',
	`marks` int,
	`feedback` text,
	`gradedById` int,
	`gradedAt` bigint,
	CONSTRAINT `submissions_id` PRIMARY KEY(`id`),
	CONSTRAINT `assignment_student_unique` UNIQUE(`assignmentId`,`studentId`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` varchar(20) NOT NULL DEFAULT 'student';--> statement-breakpoint
ALTER TABLE `users` ADD `studentId` varchar(40);--> statement-breakpoint
ALTER TABLE `users` ADD `departmentId` int;--> statement-breakpoint
ALTER TABLE `users` ADD `yearOfStudy` int;--> statement-breakpoint
ALTER TABLE `users` ADD `avatarUrl` text;--> statement-breakpoint
ALTER TABLE `users` ADD `bio` text;--> statement-breakpoint
CREATE INDEX `announcements_status_idx` ON `announcements` (`status`);--> statement-breakpoint
CREATE INDEX `announcements_published_idx` ON `announcements` (`publishedAt`);--> statement-breakpoint
CREATE INDEX `assignments_course_idx` ON `assignments` (`courseId`);--> statement-breakpoint
CREATE INDEX `assignments_faculty_idx` ON `assignments` (`facultyId`);--> statement-breakpoint
CREATE INDEX `assignments_due_idx` ON `assignments` (`dueAt`);--> statement-breakpoint
CREATE INDEX `assignments_status_idx` ON `assignments` (`status`);--> statement-breakpoint
CREATE INDEX `enrollments_student_idx` ON `course_enrollments` (`studentId`);--> statement-breakpoint
CREATE INDEX `enrollments_course_idx` ON `course_enrollments` (`courseId`);--> statement-breakpoint
CREATE INDEX `courses_status_idx` ON `courses` (`status`);--> statement-breakpoint
CREATE INDEX `courses_department_idx` ON `courses` (`departmentId`);--> statement-breakpoint
CREATE INDEX `faculty_assignments_faculty_idx` ON `faculty_course_assignments` (`facultyId`);--> statement-breakpoint
CREATE INDEX `notifications_user_idx` ON `notifications` (`userId`);--> statement-breakpoint
CREATE INDEX `notifications_unread_idx` ON `notifications` (`userId`,`readAt`);--> statement-breakpoint
CREATE INDEX `submissions_student_idx` ON `submissions` (`studentId`);--> statement-breakpoint
CREATE INDEX `submissions_assignment_idx` ON `submissions` (`assignmentId`);--> statement-breakpoint
CREATE INDEX `submissions_status_idx` ON `submissions` (`status`);--> statement-breakpoint
CREATE INDEX `users_role_idx` ON `users` (`role`);--> statement-breakpoint
CREATE INDEX `users_department_idx` ON `users` (`departmentId`);